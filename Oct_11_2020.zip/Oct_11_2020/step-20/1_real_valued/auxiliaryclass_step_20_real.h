
#ifndef AUXILIARYCLASS_STEP_20_REAL_H
#define AUXILIARYCLASS_STEP_20_REAL_H
  
  
template <int dim>                                                                                 //create the boundary for the velocity
class GradientBoundary_Step_20_Real : public Function<dim>,
public Common_Var_Real<dim>  
{
  public:
    using Common_Var_Real<dim>::Common_Var_Real;
    GradientBoundary_Step_20_Real (const unsigned int id_case, const unsigned int id_loc_coeff_diff, const double coeff_inner_x);            //  {}

    virtual void vector_value (const Point<dim> &p,
                               Vector<double>   &value) const;
  protected:
    const unsigned int id_case, id_loc_coeff_diff;
    const double coeff_inner_x;
};


template <int dim>
class ExactSolution_Step_20_Real : public Function<dim>,
public Common_Var_Real<dim>
{
  public:
    using Common_Var_Real<dim>::Common_Var_Real;
    ExactSolution_Step_20_Real (const unsigned int id_case, const unsigned int id_loc_coeff_diff, const double coeff_inner_x);          // : Function<dim>(dim+1) {}

    virtual void vector_value (const Point<dim> &p,
                               Vector<double>   &values) const;
    virtual void vector_gradient (const Point<dim> &p,
                               std::vector<Tensor<1,dim>>   &gradients) const;   
                               
protected:
  const unsigned int id_case, id_loc_coeff_diff;
  const double coeff_inner_x;                                
};


template<int dim>
GradientBoundary_Step_20_Real<dim>::GradientBoundary_Step_20_Real(const unsigned int id_case, const unsigned int id_loc_coeff_diff, const double coeff_inner_x): 
Function<dim>(dim),Common_Var_Real<dim>(id_case,coeff_inner_x),               // the argument of Function determines the number of componenets for GradientBoundary_Step_20_Real, Jan. 14, 2020
id_case(id_case),
id_loc_coeff_diff(id_loc_coeff_diff),
coeff_inner_x(coeff_inner_x)
{}


template <int dim>
ExactSolution_Step_20_Real<dim>::ExactSolution_Step_20_Real(const unsigned int id_case, const unsigned int id_loc_coeff_diff, const double coeff_inner_x): Function<dim>(dim+1),Common_Var_Real<dim>(id_case,coeff_inner_x),
id_case(id_case),
id_loc_coeff_diff(id_loc_coeff_diff),
coeff_inner_x (coeff_inner_x)
{}

  
template <int dim>
void
GradientBoundary_Step_20_Real<dim>::vector_value (const Point<dim> &p,
                            Vector<double>   &values) const
{

//   cout << "  values.size(): " << values.size() << "\n";
  Assert (values.size() == dim,
      ExcDimensionMismatch (values.size(), dim));

  switch (id_case)
  {
    case 1:
      values(0)=-pow(2.0*pi*coeff_inner_x, -1.0)*cos(2.0*pi*coeff_inner_x*p[0]);                                     // u(-dp/dx)
      break;
    case 2:
      values(0) = -exp(-coeff_inner_x*std::pow(p[0]-0.5,2))*(-2.0*coeff_inner_x*(p[0]-0.5));                 
      break;
    case 3:
      values(0)=-(pow(2.0*pi*coeff_inner_x, 2.0))*cos(2.0*pi*coeff_inner_x*p[0])+p[0];
      break;
    case 4:
      values(0)=-cos(2.0*pi*coeff_inner_x*p[0]); 
      break;
    case 5:
      values(0) = -pow(coeff_inner_x, -1.0);
      break;
    case 61:
      values(0) = -2*(p[0]-this->center_x)*this->coeff_outer_x/pow(coeff_inner_x,2.0);
      if(dim==2)
      { 
        values(1) = -2*(p[1]-this->center_y)*this->coeff_outer_y/pow(this->coeff_inner_y,2.0);  
      }
      break;
    case 62:
      values(0) = -2.0*coeff_inner_x*(coeff_inner_x*p[0]+100.0);
      break;
    case 63:
      values(0) = -2.0*p[0];
      break;
    case 64:
      values(1) = -2.0*p[1];
      break;
        
    case 21:
      if(id_loc_coeff_diff==0 or id_loc_coeff_diff == 1)
      {
        values(0) = -2.0*pi*cos(2.0*pi*p[0])*(p[0]*coeff_inner_x+1.0);
      }else if(id_loc_coeff_diff==2)
      {
        values(0) = -2.0*pi*cos(2.0*pi*p[0]); 
      }              
      break;
    case 22:
      values(0) = -(1.0+0.5*sin(coeff_inner_x*p[0]))*exp(-std::pow(p[0]-0.5,2))*(-2.0*(p[0]-0.5));
      break;    
    case 24:
    case 241:
      values(0) = -(1.0+coeff_inner_x*p[0])*exp(-std::pow(p[0]-0.5,2))*(-2.0*(p[0]-0.5));
      break;                 
        
    case 25:
      values(0) = -pow(2.0*pi*coeff_inner_x, -1.0)*cos(2.0*pi*coeff_inner_x*p[0])*this->coeff_diff_inde;
      break;                 
    case 26:
      values(0) = -pow(2.0*pi*coeff_inner_x, -1.0)*cos(2.0*pi*coeff_inner_x*p[0])*(1.0+this->coeff_diff_inde*p[0]);
      break;                 

        
    case 8:
      values(0) = -(1.0+0.5*sin(p[0]))*exp(-std::pow(p[0]-0.5,2))*(-2.0*(p[0]-0.5));
      break;  
    case 81:
      values(0) = -exp(-std::pow(p[0]-0.5,2))*(-2.0*(p[0]-0.5));
      break;                

    default:
      cout << "case does not exist" << endl;
      throw exception();              
  }
}
  
  
template <int dim>
void
ExactSolution_Step_20_Real<dim>::vector_value (const Point<dim> &p,
                                Vector<double>   &values) const
{
//     std::cout << "    ExactSolution_Step_20_Real::vector_value()" << std::endl;
  Assert (values.size() == dim+1,
          ExcDimensionMismatch (values.size(), dim+1));

  switch (id_case)
  {
    case 1:
      values(0)=-pow(2.0*pi*coeff_inner_x, -1.0)*cos(2.0*pi*coeff_inner_x*p[0]);           // u, equal to the gradient boundary, is -dp/dx for poisson equations, and -adp/dx for diffusion equations, affecting error of the first derivative
      values(1)=pow(2.0*pi*coeff_inner_x, -2.0)*sin(2.0*pi*coeff_inner_x*p[0]);            // p, equal to the pressure boundary, affecting the error of the solution
        break;
    case 2:
      values(0) = -exp(-coeff_inner_x*std::pow(p[0]-0.5,2))*(-2.0*coeff_inner_x*(p[0]-0.5));   
      if(dim==2)
      {
        values(1) = 0.0;
      }
      values(dim) = exp(-coeff_inner_x*std::pow(p[0]-0.5,2));  
      break;
    case 3:
      values(0)=-(pow(2.0*pi*coeff_inner_x, -1.0))*cos(2.0*pi*coeff_inner_x*p[0])+p[0];
      values(1)=std::pow(2.0*pi*coeff_inner_x, -2.0)*sin(2.0*pi*coeff_inner_x*p[0])-std::pow(p[0],2)/2.0;
      break;
    case 4:
      values(0)=-cos(2.0*pi*coeff_inner_x*p[0]); 
      values(1)=pow(2.0*pi*coeff_inner_x, -1.0)*sin(2.0*pi*coeff_inner_x*p[0]);
      break;
    case 5:
      values(0) = -pow(coeff_inner_x, -1.0);
      values(1) = pow(coeff_inner_x, -1.0)*p[0];
      break;
    case 61:
      if(dim==1)
      {
        values(0) = -2*(p[0]-this->center_x)*this->coeff_outer_x/pow(coeff_inner_x,2.0);                        // -px
        values(1) = this->coeff_outer_x*pow((p[0]-this->center_x)/coeff_inner_x,2)+this->const_inde;            // p
      }else if(dim==2)
      {
        values(0) = -2*(p[0]-this->center_x)*this->coeff_outer_x/pow(coeff_inner_x,2.0);                        // -px
        values(1) = -2*(p[1]-this->center_y)*this->coeff_outer_y/pow(this->coeff_inner_y,2.0);                  // -py
        values(2) = this->coeff_outer_x*pow((p[0]-this->center_x)/coeff_inner_x,2)+this->coeff_outer_y*pow((p[1]-this->center_y)/this->coeff_inner_y,2)+this->const_inde;           // p 
      }
      break;
    case 62:
      values(0) = -2.0*coeff_inner_x*(coeff_inner_x*p[0]+100.0);
      if(dim==2)
      {
        values(1) = 0.0;
      }
      values(dim) = pow(coeff_inner_x*p[0]+100.0,2.0);  
      break;
    case 63:
      values(0) = -2.0*p[0];
      if(dim==2)
      {
        values(1) = 0.0;
      }
      values(dim) = pow(p[0],2.0)-pow(coeff_inner_x,2.0);
      break;
    case 64:
      values(0) = -2.0*p[0];
      if(dim==2)
      {
        values(1) = -2.0*p[1];
      }
      values(dim) = pow(p[0],2.0)+pow(p[1],2.0)-pow(coeff_inner_x,2.0);
      break;
    
    case 21:
      if(id_loc_coeff_diff==0 or id_loc_coeff_diff == 1)
      {
        values(0) = -2.0*pi*cos(2.0*pi*p[0])*(p[0]*coeff_inner_x+1.0);
      }else if(id_loc_coeff_diff==2)
      {
        values(0) = -2.0*pi*cos(2.0*pi*p[0]); 
      }
      values(1) = sin(2.0*pi*p[0])+this->const_inde;
      break;
    case 22:
      values(0) = -(1.0+0.5*sin(coeff_inner_x*p[0]))*exp(-std::pow(p[0]-0.5,2))*(-2.0*(p[0]-0.5));
      values(1) = exp(-std::pow(p[0]-0.5,2));          
      break;
    case 24:
      values(0) = -(1.0+coeff_inner_x*p[0])*exp(-std::pow(p[0]-0.5,2))*(-2.0*(p[0]-0.5));
      values(1) = exp(-std::pow(p[0]-0.5,2));          
      break;
    case 241:
      values(0) = -(coeff_inner_x)*exp(-std::pow(p[0]-0.5,2))*(-2.0*(p[0]-0.5));
      values(1) = exp(-std::pow(p[0]-0.5,2));          
      break;
    case 25:
      values(0)=-pow(2.0*pi*coeff_inner_x, -1.0)*cos(2.0*pi*coeff_inner_x*p[0])*this->coeff_diff_inde;
      values(1)= pow(2.0*pi*coeff_inner_x, -2.0)*sin(2.0*pi*coeff_inner_x*p[0]);
      break;              
    case 26:
      values(0)=-pow(2.0*pi*coeff_inner_x, -1.0)*cos(2.0*pi*coeff_inner_x*p[0])*(1.0+this->coeff_diff_inde*p[0]);
      values(1)= pow(2.0*pi*coeff_inner_x, -2.0)*sin(2.0*pi*coeff_inner_x*p[0]);
      break;              
        
        
    case 8:
      values(0) = -(1.0+0.5*sin(p[0]))*exp(-std::pow(p[0]-0.5,2))*(-2.0*(p[0]-0.5));
      values(1) = exp(-std::pow(p[0]-0.5,2));          
      break;
    case 81:
      values(0) = -exp(-std::pow(p[0]-0.5,2))*(-2.0*(p[0]-0.5));
      values(1) = exp(-std::pow(p[0]-0.5,2));     
      break;
        
        
    default:
      cout << "case does not exist" << endl;
      throw exception();              
  }
}
  
template <int dim>
void
ExactSolution_Step_20_Real<dim>::vector_gradient (const Point<dim> &p,
                                     std::vector<Tensor<1,dim>>   &gradients) const
{      
//   std::cout << "      ExactSolution_Step_20_Real::vector_gradient()" << std::endl;
//   cout << "  coeff_inner_x: " << coeff_inner_x << "\n";
      
  switch (id_case)
  {
    case 1:
      gradients[0][0] = sin(2.0*pi*coeff_inner_x*p[0]);                                             // du/dx, equal to rhs, affecting error of du/dx, 
      gradients[1][0] = pow(2.0*pi*coeff_inner_x, -1.0)*cos(2.0*pi*coeff_inner_x*p[0]);             // dp/dx, opposite of the gradient boundary for the Poisson equation 
      break;
    case 2:
      gradients[0][0] = -exp(-coeff_inner_x*std::pow(p[0]-0.5,2))*(std::pow(2*coeff_inner_x*(p[0]-0.5),2)-2.0*coeff_inner_x);           // -pxx
      if(dim==1)
      {
        gradients[1][0] = std::exp(-coeff_inner_x*std::pow(p[0]-0.5,2))*(-2.0*coeff_inner_x*(p[0]-0.5));                        // px
      }else if(dim==2)
      {    
        gradients[0][1] = 0.0;         //-pxy
        gradients[1][0] = gradients[0][1];         //-pyx
        gradients[1][1] = 0.0;          //-pyy
        gradients[2][0] = exp(-(this->coeff_outer_x*pow(p[0]-this->center_x,2)+this->coeff_outer_y*pow(p[1]-this->center_y,2))/this -> coeff_inner_x)*(-2*this->coeff_outer_x*(p[0]-this->center_x)/this -> coeff_inner_x);     //px
        gradients[2][1] = exp(-(this->coeff_outer_x*pow(p[0]-this->center_x,2)+this->coeff_outer_y*pow(p[1]-this->center_y,2))/this -> coeff_inner_x)*(-2*this->coeff_outer_y*(p[1]-this->center_y)/this -> coeff_inner_x);     //py
      }
    
      break;
    case 3:
      gradients[0][0] = sin(2.0*pi*coeff_inner_x*p[0])+1.0;
      gradients[1][0] = pow(2.0*pi*coeff_inner_x, -1.0)*cos(2.0*pi*coeff_inner_x*p[0])-p[0];
      break;
    case 4:
      gradients[0][0] = 2.0*pi*coeff_inner_x*sin(2.0*pi*coeff_inner_x*p[0]);
      gradients[1][0] = cos(2.0*pi*coeff_inner_x*p[0]);
      break;
    case 5:
      gradients[0][0] = 0.0;
      gradients[1][0] = pow(coeff_inner_x, -1.0);
      break;
    case 61:
      gradients[0][0] = -2.0*this->coeff_outer_x/pow(coeff_inner_x,2);                            // see Case 2 for the representation
      if(dim==1)
      {
        gradients[1][0] = 2*(p[0]-this->center_x)*this->coeff_outer_x/pow(coeff_inner_x,2.0);
      }
      if (dim==2)
      {
        gradients[0][0] = -2.0*this->coeff_outer_x/pow(coeff_inner_x,2);
        gradients[0][1] = 0.0;
        gradients[1][0] = 0.0;
        gradients[1][1] = -2.0*this->coeff_outer_y/pow(this->coeff_inner_y,2);
        
        gradients[2][0] = 2*(p[0]-this->center_x)*this->coeff_outer_x/pow(coeff_inner_x,2.0);
        gradients[2][1] = 2*(p[0]-this->center_y)*this->coeff_outer_y/pow(this->coeff_inner_y,2.0);
      }
      break;
    case 62:
      gradients[0][0] = -2.0*pow(coeff_inner_x,2.0);
      if (dim==2)
      {
        gradients[0][1] = 0.0;
        gradients[1][0] = gradients[0][1];
        gradients[1][1] = 0.0;
        
        gradients[2][1] = 0.0;
      }
      gradients[dim][0] = 2.0*coeff_inner_x*(coeff_inner_x*p[0]+100.0);
      break;
    case 63:
      gradients[0][0] = -2.0;
      if (dim==2)
      {
        gradients[0][1] = 0.0;
        gradients[1][0] = gradients[0][1];
        gradients[1][1] = 0.0;
        
        gradients[2][1] = 0.0;
      }
      gradients[dim][0] = 2.0*p[0];
      break;
    case 64:
      gradients[0][0] = -2.0;
      if (dim==2)
      {
        gradients[0][1] = 0.0;
        gradients[1][0] = gradients[0][1];
        gradients[1][1] = -2.0;
        
        gradients[2][1] = 2.0*p[1];
      }
      gradients[dim][0] = 2.0*p[0];
      break;
        
    case 21:
      if(id_loc_coeff_diff==0 or id_loc_coeff_diff == 1)
      {
        gradients[0][0] = -2.0*pi*(cos(2.0*pi*p[0])*coeff_inner_x+(1.0+coeff_inner_x* p[0])*(-2.0*pi*sin(2.0*pi*p[0])));
      }else if (id_loc_coeff_diff==2)
      {    
        gradients[0][0] = pow(2.0*pi,2)*sin(2.0*pi*p[0]);
      }
      gradients[1][0] = 2.0*pi*cos(2.0*pi*p[0]);
      break;
    case 22:
      gradients[0][0] = -exp(-pow(p[0]-this->center_x,2.0))*(0.5*coeff_inner_x*cos(coeff_inner_x*p[0])*(-2*(p[0]-0.5))+(1.0+0.5*sin(coeff_inner_x*p[0]))*(pow(2*(p[0]-this->center_x),2)-2.0));
      gradients[1][0] = exp(-std::pow(p[0]-0.5,2))*(-2.0*(p[0]-0.5));
      break;    
    case 24:
      gradients[0][0] = -exp(-pow(p[0]-this->center_x,2.0))*                              
                        (coeff_inner_x*(-2*(p[0]-0.5))               
                        +(1.0+coeff_inner_x*p[0])*(pow(2*(p[0]-this->center_x),2)-2.0));    
      gradients[1][0] = exp(-std::pow(p[0]-0.5,2))*(-2.0*(p[0]-0.5));
      break;    
    case 241:
      gradients[0][0] = -exp(-pow(p[0]-this->center_x,2.0))*                               
                        (coeff_inner_x*(pow(2*(p[0]-this->center_x),2)-2.0));     
      gradients[1][0] = exp(-std::pow(p[0]-0.5,2))*(-2.0*(p[0]-0.5));
      break;    
        
    case 25:
      gradients[0][0] = sin(2.0*pi*coeff_inner_x*p[0])*this->coeff_diff_inde;
      gradients[1][0] = pow(2.0*pi*coeff_inner_x, -1.0)*cos(2.0*pi*coeff_inner_x*p[0]);
      break;              
    case 26:
      gradients[0][0] = -this->coeff_diff_inde*pow(2.0*pi*coeff_inner_x, -1.0)*cos(2.0*pi*coeff_inner_x*p[0]) + (1.0+this->coeff_diff_inde*p[0])*sin(2.0*pi*coeff_inner_x*p[0]);
      gradients[1][0] = pow(2.0*pi*coeff_inner_x, -1.0)*cos(2.0*pi*coeff_inner_x*p[0]);
      break;
        
    case 8:
      gradients[0][0] = -exp(-pow(p[0]-this->center_x,2.0))*(0.5*cos(p[0])*(-2*(p[0]-0.5))+(1.0+0.5*sin(p[0]))*(pow(2*(p[0]-this->center_x),2)-2.0));
      gradients[1][0] = exp(-std::pow(p[0]-0.5,2))*(-2.0*(p[0]-0.5));
      break;   
    case 81:
      gradients[0][0] = -exp(-pow(p[0]-this->center_x,2.0))*(pow(2*(p[0]-this->center_x),2)-2.0);     
      gradients[1][0] = exp(-std::pow(p[0]-0.5,2))*(-2.0*(p[0]-0.5));
      break;                 
        
        
    default:
      cout << "case does not exist" << endl;
      throw exception();              
  }
}


#endif



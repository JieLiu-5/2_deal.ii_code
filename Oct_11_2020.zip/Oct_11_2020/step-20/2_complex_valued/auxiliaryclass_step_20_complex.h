
#ifndef AUXILIARYCLASS_STEP_20_COMPLEX_H
#define AUXILIARYCLASS_STEP_20_COMPLEX_H

template <int dim>
class GradientBoundary_Step_20_Complex : public Function<dim>,
public Common_Var_Complex<dim>
{
  public:
    using Common_Var_Complex<dim>::Common_Var_Complex;
    GradientBoundary_Step_20_Complex (const unsigned int id_case);
    virtual void vector_value (const Point<dim> &p,
                               Vector<double>   &value) const;
  protected:
    const unsigned int id_case;                                  
};

template <int dim>
class GradientBoundary_Step_20_Complex_Real : public Function<dim>,
public Common_Var_Complex<dim>
{
  public:
    using Common_Var_Complex<dim>::Common_Var_Complex;
    GradientBoundary_Step_20_Complex_Real (const unsigned int id_case);
    virtual void vector_value (const Point<dim> &p,
                               Vector<double>   &value) const;
  protected:
    const unsigned int id_case;                                  
};

template <int dim>
class GradientBoundary_Step_20_Complex_Imag : public Function<dim>,
public Common_Var_Complex<dim>
{
  public:
    using Common_Var_Complex<dim>::Common_Var_Complex;
    GradientBoundary_Step_20_Complex_Imag (const unsigned int id_case);
    virtual void vector_value (const Point<dim> &p,
                               Vector<double>   &value) const;
  protected:
    const unsigned int id_case;                                  
};

template <int dim>
class ExactSolution_Step_20_Complex_Real : public Function<dim>,
public Common_Var_Complex<dim>
{
  public:
    using Common_Var_Complex<dim>::Common_Var_Complex;
    
    ExactSolution_Step_20_Complex_Real (const unsigned int id_case);

    virtual void vector_value (const Point<dim> &p,
                               Vector<double>   &value) const;
    virtual void vector_gradient (const Point<dim> &p,
                               vector<Tensor<1,dim>>   &gradients) const;
  protected:
    const unsigned int id_case;
};

template <int dim>
class ExactSolution_Step_20_Complex_Imag : public Function<dim>,
public Common_Var_Complex<dim>
{
  public:
    using Common_Var_Complex<dim>::Common_Var_Complex;
    ExactSolution_Step_20_Complex_Imag (const unsigned int id_case);

    virtual void vector_value (const Point<dim> &p,
                               Vector<double>   &value) const;
    virtual void vector_gradient (const Point<dim> &p,
                               vector<Tensor<1,dim>>   &gradients) const;
  protected:
    const unsigned int id_case;                               
};


template <int dim>
GradientBoundary_Step_20_Complex<dim>::GradientBoundary_Step_20_Complex(const unsigned int id_case): Function<dim>(2*(dim+1)),Common_Var_Complex<dim>(id_case),
id_case(id_case)
{}

template <int dim>
GradientBoundary_Step_20_Complex_Real<dim>::GradientBoundary_Step_20_Complex_Real(const unsigned int id_case): Function<dim>(2),Common_Var_Complex<dim>(id_case),
id_case(id_case)
{}

template <int dim>
GradientBoundary_Step_20_Complex_Imag<dim>::GradientBoundary_Step_20_Complex_Imag(const unsigned int id_case): Function<dim>(2),Common_Var_Complex<dim>(id_case),
id_case(id_case)
{}

template <int dim>
ExactSolution_Step_20_Complex_Real<dim>::ExactSolution_Step_20_Complex_Real(const unsigned int id_case):Function<dim>(dim+1),Common_Var_Complex<dim>(id_case),
id_case(id_case)
{}
  
template <int dim>
ExactSolution_Step_20_Complex_Imag<dim>::ExactSolution_Step_20_Complex_Imag(const unsigned int id_case):Function<dim>(dim+1),Common_Var_Complex<dim>(id_case),
id_case(id_case)
{}


template <int dim>
void
GradientBoundary_Step_20_Complex<dim>::vector_value (const Point<dim> &p,
                                                     Vector<double>   &values) const
{
    
  complex<double> value_coeff_d = 0.0 + 0.0i;
  value_coeff_d = -this->constant_coeff_d*exp(-p[0]);           // 1.0 + 0.0i;
  
//   cout << "  at " << p << ", ";
//   cout << "value_coeff_d: " << value_coeff_d << "\n";
  
  switch(id_case)
  {
    case 1:
      break;
    case 2:
      if(dim==1)
      {
        values(0) = - this->coeff_b;      // u_real(-dp/dx)|x=1
        values(1) = 0;
        values(2) = 0;
        values(3) = 0;  
      }else if(dim==2)
      {   
        values(0) = -((this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0]))*value_coeff_d).real()*cos(this->coeff_y*(p[1]-this->centre_y)); // real -dp_x
        values(1) = -((this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]))*value_coeff_d).real()*(-this->coeff_y)*sin(this->coeff_y*(p[1]-this->centre_y));  // real -dp_y                                                                                              
        values(3) = -((this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0]))*value_coeff_d).imag()*cos(this->coeff_y*(p[1]-this->centre_y)); // imag -dp_x
        values(4) = -((this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]))*value_coeff_d).imag()*(-this->coeff_y)*sin(this->coeff_y*(p[1]-this->centre_y));  // imag -dp_y 
      }
      break;
    default:
      cout << "  case does not exist \n";
  }
}

template <int dim>
void
GradientBoundary_Step_20_Complex_Real<dim>::vector_value (const Point<dim> &p,
                                                          Vector<double>   &values) const
{
  Assert (2 == dim, ExcDimensionMismatch (2, dim));
    
  complex<double> value_coeff_d = 0.0 + 0.0i;
  value_coeff_d = -this->constant_coeff_d*exp(-p[0]);           // 1.0 + 0.0i;
  
  switch(id_case)
  {
    case 1:
      break;
    case 2:
      values(0) = -((this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0]))*value_coeff_d).real()*cos(this->coeff_y*(p[1]-this->centre_y)); // real -dp_x
      values(1) = -((this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]))*value_coeff_d).real()*(-this->coeff_y)*sin(this->coeff_y*(p[1]-this->centre_y));  // real -dp_y
      break;
    default:
      cout << "  case does not exist \n";
  }
}
  
template <int dim>
void
GradientBoundary_Step_20_Complex_Imag<dim>::vector_value (const Point<dim> &p,
                                                          Vector<double>   &values) const
{
  Assert (2 == dim, ExcDimensionMismatch (2, dim));
    
  complex<double> value_coeff_d = 0.0 + 0.0i;
  value_coeff_d = -this->constant_coeff_d*exp(-p[0]);           // 1.0 + 0.0i;
  
  switch(id_case)
  {
    case 1:
      break;
    case 2:
        values(0) = -((this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0]))*value_coeff_d).imag()*cos(this->coeff_y*(p[1]-this->centre_y)); // imag -dp_x
        values(1) = -((this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]))*value_coeff_d).imag()*(-this->coeff_y)*sin(this->coeff_y*(p[1]-this->centre_y));  // imag -dp_y
      break;
    default:
      cout << "  case does not exist \n";
  }
}

template <int dim>
void
ExactSolution_Step_20_Complex_Real<dim>::vector_value (const Point<dim> &p,
                                Vector<double>   &values) const
{
  Assert (values.size() == dim+1,
          ExcDimensionMismatch (values.size(), dim+1));
    
  switch (id_case)
  {
    case 1:
      cout << "  exact solution does not exist\n";
      throw exception();
    case 2:
      if (dim==1)
      {
        values(0) = ((this->A*this->r1*exp(this->r1*p[0])+this->B*this->r2*exp(this->r2*p[0]))*(this->constant_coeff_d*exp(-p[0]))).real();            // real -dp_x
        values(1) = (this->A*exp(this->r1*p[0])+this->B*exp(this->r2*p[0])).real();                                                                 // real p   
      }else if(dim==2)
      {        
        values(0) = ((this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0]))*(this->constant_coeff_d*exp(-p[0]))).real()*cos(this->coeff_y*(p[1]-this->centre_y));             // real -dp_x
        values(1) = ((this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]))*(this->constant_coeff_d*exp(-p[0]))).real()*(-this->coeff_y)*sin(this->coeff_y*(p[1]-this->centre_y));              // real -dp_y
        values(2) = (this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0])).real()*cos(this->coeff_y*(p[1]-this->centre_y));          // real p         
      }
      break;
    default:
      cout << "  case does not exist\n";
      throw exception();
  }
}

template <int dim>
void
ExactSolution_Step_20_Complex_Real<dim>::vector_gradient (const Point<dim> &p,
                                                        vector<Tensor<1,dim>>   &gradients) const
{
  switch (id_case)
  {    
    case 1:
      cout << "  exact solution does not exist\n";
      throw exception();
    case 2:
      if (dim==1)
      {
        gradients[0][0] = ((this->A*pow(this->r1,2.0)*exp(this->r1*p[0])+this->B*pow(this->r2,2.0)*exp(this->r2*p[0]))*(this->constant_coeff_d*exp(-p[0]))+
                          (this->A*this->r1*exp(this->r1*p[0])+this->B*this->r2*exp(this->r2*p[0]))*(-this->constant_coeff_d*exp(-p[0]))).real();
        gradients[1][0] = 2;//(this->A*this->r1*exp(this->r1*p[0])+this->B*this->r2*exp(this->r2*p[0])).real();
      }else if(dim==2)
      {
        gradients[0][0] = -(((this->constant_coeff_d*exp(-p[0]))*(this->A*this->r1*exp(this->r1*p[0])+this->B*this->r2*exp(this->r2*p[0]))).real()-((this->A*pow(this->r1,2)*std::exp(this->r1*p[0])+this->B*pow(this->r2,2)*std::exp(this->r2*p[0]))*(this->constant_coeff_d*exp(-p[0]))).real())*cos(this->coeff_y*(p[1]-this->centre_y));                        // real -(dp_x)_x
        gradients[0][1] = ((this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0]))*(this->constant_coeff_d*exp(-p[0]))).real()*(-this->coeff_y)*sin(this->coeff_y*(p[1]-this->centre_y));    // real -(dp_x)_y
	    gradients[1][0] = ((this->constant_coeff_d*exp(-p[0]))*(this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]))).real()*(-this->coeff_y)*sin(this->coeff_y*(p[1]-this->centre_y))+((this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0]))*(this->constant_coeff_d*exp(-p[0]))).real()*(-this->coeff_y)*sin(this->coeff_y*(p[1]-this->centre_y));   // real -(dp_y)_x
        gradients[1][1] = ((this->constant_coeff_d*exp(-p[0]))*(this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]))).real()*(-pow(this->coeff_y,2))*cos(this->coeff_y*(p[1]-this->centre_y));            // real -(dp_y)_y
        gradients[2][0] = (this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0])).real()*cos(this->coeff_y*(p[1]-this->centre_y));       // real px
        gradients[2][1] = (this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0])).real()*(-this->coeff_y)*sin(this->coeff_y*(p[1]-this->centre_y));        // real py        
      }        

      break;
    default:
      cout << "  case does not exist\n";
      throw exception();      
  }
}
  
  
template <int dim>
void
ExactSolution_Step_20_Complex_Imag<dim>::vector_value (const Point<dim> &p,
                                Vector<double>   &values) const
{
  Assert (values.size() == dim+1,
          ExcDimensionMismatch (values.size(), dim+1));
  switch (id_case)
  {    
    case 1:
      cout << "  exact solution does not exist\n";
      throw exception();
    case 2:
      if (dim==1)
      {
        values(0) = ((this->A*this->r1*exp(this->r1*p[0])+this->B*this->r2*exp(this->r2*p[0]))*(this->constant_coeff_d*exp(-p[0]))).imag();
        values(1) = (this->A*exp(this->r1*p[0])+this->B*exp(this->r2*p[0])).imag();
      }else if(dim==2)
      {        
        values(0) = ((this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0]))*(this->constant_coeff_d*exp(-p[0]))).imag()*cos(this->coeff_y*(p[1]-this->centre_y));             // imag -dp_x
        values(1) = ((this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]))*(this->constant_coeff_d*exp(-p[0]))).imag()*(-this->coeff_y)*sin(this->coeff_y*(p[1]-this->centre_y));              // imag -dp_y
        values(2) = (this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0])).imag()*cos(this->coeff_y*(p[1]-this->centre_y));          // imag p        
      }
      break;
    default:
      cout << "  case does not exist\n";
      throw exception();      
  }
}

template <int dim>
void
ExactSolution_Step_20_Complex_Imag<dim>::vector_gradient (const Point<dim> &p,
                                                        vector<Tensor<1,dim>>   &gradients) const
{
  switch (id_case)
  {
    case 1:
      cout << "  exact solution does not exist\n";
      throw exception();
    case 2:
      if (dim==1)
      {
        gradients[0][0] = ((this->A*pow(this->r1,2.0)*exp(this->r1*p[0])+this->B*pow(this->r2,2.0)*exp(this->r2*p[0]))*(this->constant_coeff_d*exp(-p[0]))+
                          (this->A*this->r1*exp(this->r1*p[0])+this->B*this->r2*exp(this->r2*p[0]))*(-this->constant_coeff_d*exp(-p[0]))).imag();
        gradients[1][0] = (this->A*this->r1*exp(this->r1*p[0])+this->B*this->r2*exp(this->r2*p[0])).imag();
      }else if(dim==2)
      {        
        gradients[0][0] = -(((this->constant_coeff_d*exp(-p[0]))*(this->A*this->r1*exp(this->r1*p[0])+this->B*this->r2*exp(this->r2*p[0]))).imag()-((this->A*pow(this->r1,2)*std::exp(this->r1*p[0])+this->B*pow(this->r2,2)*std::exp(this->r2*p[0]))*(this->constant_coeff_d*exp(-p[0]))).imag())*cos(this->coeff_y*(p[1]-this->centre_y));                        // imag -(dp_x)_x
        gradients[0][1] = ((this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0]))*(this->constant_coeff_d*exp(-p[0]))).imag()*(-this->coeff_y)*sin(this->coeff_y*(p[1]-this->centre_y));    // imag -(dp_x)_y
	    gradients[1][0] = ((this->constant_coeff_d*exp(-p[0]))*(this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]))).imag()*(-this->coeff_y)*sin(this->coeff_y*(p[1]-this->centre_y))+((this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0]))*(this->constant_coeff_d*exp(-p[0]))).imag()*(-this->coeff_y)*sin(this->coeff_y*(p[1]-this->centre_y));   // imag -(dp_y)_x
        gradients[1][1] = ((this->constant_coeff_d*exp(-p[0]))*(this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]))).imag()*(-pow(this->coeff_y,2))*cos(this->coeff_y*(p[1]-this->centre_y));            // imag -(dp_y)_y
        gradients[2][0] = (this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0])).imag()*cos(this->coeff_y*(p[1]-this->centre_y));       // imag px
        gradients[2][1] = (this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0])).imag()*(-this->coeff_y)*sin(this->coeff_y*(p[1]-this->centre_y));        // imag py         
      }
      break;
    default:
      cout << "  case does not exist\n";
      throw exception();
  }      
}
  

template <int dim>
class Zero_Function_Custom : public Function<dim>
{
  public:
    Zero_Function_Custom () : Function<dim>(dim+1) {}

    virtual void vector_value (const Point<dim> &p,
                               Vector<double>   &value) const;
    virtual void vector_gradient (const Point<dim> &p,
                               vector<Tensor<1,dim>>   &gradients) const;
};
  
template <int dim>
void
Zero_Function_Custom<dim>::vector_value (const Point<dim> &/*p*/,
                                  Vector<double>   &values) const
{
  Assert (values.size() == dim+1,
          ExcDimensionMismatch (values.size(), dim+1));
  values(0) = 0.0;
  values(1) = 0.0;
}

template <int dim>
void
Zero_Function_Custom<dim>::vector_gradient (const Point<dim> &/*p*/,
                                          vector<Tensor<1,dim>>   &gradients) const
{
  gradients[0][0] = 0.0;
  gradients[1][0] = 0.0;
}

#endif



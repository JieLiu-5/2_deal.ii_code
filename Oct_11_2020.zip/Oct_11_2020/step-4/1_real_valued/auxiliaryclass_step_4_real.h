
#ifndef AUXILIARYCLASS_STEP_4_REAL_H
#define AUXILIARYCLASS_STEP_4_REAL_H


template <int dim>
class ExactSolution_Step_4_Real:
public Function<dim>,
public Common_Var_Real<dim>
{
public:
  using Common_Var_Real<dim>::Common_Var_Real;
  ExactSolution_Step_4_Real (const unsigned int id_case, const double coeff_inner_x);
  
  const unsigned int id_case;
  const double coeff_inner_x;
  
  virtual double value (const Point<dim>   &p,
                        const unsigned int  component = 0) const;
  virtual Tensor<1,dim> gradient (const Point<dim>   &p,
                                  const unsigned int  component = 0) const;
  virtual SymmetricTensor<2,dim> hessian (const Point<dim>   &p,
                                  const unsigned int  component = 0) const;
};


template <int dim>
ExactSolution_Step_4_Real<dim>::ExactSolution_Step_4_Real(const unsigned int id_case, const double coeff_inner_x):
Common_Var_Real<dim>(id_case,coeff_inner_x),
id_case(id_case),
coeff_inner_x(coeff_inner_x)
{}


template <int dim>
double ExactSolution_Step_4_Real<dim> :: value (const Point<dim>   &p,
                                                const unsigned int ) const
{
  double return_value=0.0;
  switch (id_case)
  {
    case 1:
    case 25:
      return_value = pow(2.0*pi*this->coeff_inner_x, -2.0)*sin(2.0*pi*this->coeff_inner_x*p[0]);
      break;
    case 2:
      return_value = exp(-this->coeff_inner_x*std::pow(p[0]-0.5,2));  
      break;
    case 3:
      return_value = std::pow(2.0*pi*this->coeff_inner_x, -2.0)*sin(2.0*pi*this->coeff_inner_x*p[0])-std::pow(p[0],2)/2.0;
      break;
    case 4:
      return_value = pow(2.0*pi*this->coeff_inner_x, -1.0)*sin(2.0*pi*this->coeff_inner_x*p[0]);
      break;
    case 5:
      return_value = pow(this->coeff_inner_x, -1.0)*p[0];
      break;
    case 61:
      if (dim==1)
      {
        return_value = this->coeff_outer_x*pow((p[0]-this->center_x)/this->coeff_inner_x,2)+this->const_inde;
      }else if(dim==2)
      {
        return_value = this->coeff_outer_x*pow((p[0]-this->center_x)/this->coeff_inner_x,2)+this->coeff_outer_y*pow((p[1]-this->center_y)/this->coeff_inner_y,2)+this->const_inde;  
      }
      break;
    case 22:
    case 24:
    case 241:
    case 8:
    case 80:
    case 81:
    case 82:
    case 83:
    case 9:
      return exp(-std::pow((p[0]-this->center_x),2));
      break;
    case 26:
      return_value = sin(2.0*pi*p[0]);
      break;
        
    default:
      cout << "case does not exist in ExactSolution_Step_4_Real<dim>::value()\n";
      throw exception();
  }
    
  return return_value;
}

template <int dim>
Tensor<1,dim> ExactSolution_Step_4_Real<dim>::gradient (const Point<dim>   &p,
                                       const unsigned int) const
{
  Tensor<1,dim> return_value;

  switch (id_case)
  {
    case 1:
    case 25:
      return_value[0] = pow(2.0*pi*this->coeff_inner_x, -1.0)*cos(2.0*pi*this->coeff_inner_x*p[0]);
      break;
    case 2:
      return_value[0] = std::exp(-this->coeff_inner_x*std::pow(p[0]-0.5,2))*(-2.0*this->coeff_inner_x*(p[0]-0.5));
      break;
    case 3:
      return_value[0] = pow(2.0*pi*this->coeff_inner_x, -1.0)*cos(2.0*pi*this->coeff_inner_x*p[0])-p[0];
      break;
    case 4:
      return_value[0] = cos(2.0*pi*this->coeff_inner_x*p[0]);
      break;
    case 5:
      return_value[0] = pow(this->coeff_inner_x, -1.0);
      break;
    case 61:
      if (dim==1)
      {
        return_value[0] = 2*(p[0]-this->center_x)*this->coeff_outer_x/pow(this->coeff_inner_x,2.0);
      }else if(dim==2)
      {
        return_value[0] = 2*(p[0]-this->center_x)*this->coeff_outer_x/pow(this->coeff_inner_x,2.0);
        return_value[1] = 2*(p[1]-this->center_y)*this->coeff_outer_y/pow(this->coeff_inner_y,2.0);
      }        
      break;    
    case 22:
    case 24:
    case 241:
    case 8:
    case 80:
    case 81:
    case 82:
    case 83:
    case 9:
      return_value[0] = std::exp(-pow(p[0]-this->center_x,2))*(-2.0*(p[0]-this->center_x));
      break;              
        
    case 26:
      return_value[0] = 2.0*pi*cos(2.0*pi*p[0]);
      break;
        
    default:
      cout << "case does not exist in ExactSolution_Step_4_Real<dim>::gradient()\n";
      throw exception();              
  }
  
  return return_value;
}

template <int dim>
SymmetricTensor<2,dim> ExactSolution_Step_4_Real<dim>::hessian (const Point<dim>   &p,
                                       const unsigned int) const
{
  SymmetricTensor<2,dim> return_value;
  switch (id_case)
  {
    case 1:
    case 25:
      return_value[0][0] = -sin(2.0*pi*this->coeff_inner_x*p[0]);
      break;
    case 2:
      return_value[0][0] = exp(-this->coeff_inner_x*std::pow(p[0]-0.5,2))*(std::pow(2*this->coeff_inner_x*(p[0]-0.5),2)-2.0*this->coeff_inner_x);                      //dp/dx
      break;
    case 3:
      return_value[0][0] = -(sin(2.0*pi*this->coeff_inner_x*p[0])+1.0);
      break;
    case 4:
      return_value[0][0] = -2.0*pi*this->coeff_inner_x*sin(2.0*pi*this->coeff_inner_x*p[0]);
      break;
    case 5:
      return_value[0][0] =  0.0;
      break;
    case 61:
      if (dim==1)
      {
        return_value[0][0] = 2.0*this->coeff_outer_x/pow(this->coeff_inner_x,2);
      }else if(dim==2)
      {
        return_value[0][0] = 2.0*this->coeff_outer_x/pow(this->coeff_inner_x,2);  
        return_value[0][1] = 0.0;
        return_value[1][0] = 0.0;
        return_value[1][1] = 2.0*this->coeff_outer_y/pow(this->coeff_inner_y,2);
      }        
      break;            
      break;      
    case 22:
    case 24:
    case 241:
    case 8:
    case 80:
    case 81:
    case 82:
    case 83:
    case 9:
      return_value[0][0] = exp(-(p[0]-this->center_x)*(p[0]-this->center_x))*(pow(2*(p[0]-this->center_x),2)-2.0);                      //dp/dx
      break;              
        
    case 26:
      return_value[0][0] = -pow(2*pi,2.0)*sin(2.0*pi*p[0]);        // -2*pi*(this->coeff_inner_x*cos(2*pi*p[0])+(1.0+this->coeff_inner_x*p[0])*(-2*pi*sin(2*pi*p[0]))); 
      break;
        
    default:
      cout << "case does not exist in ExactSolution_Step_4_Real<dim>::hessian()\n";
      throw exception();              
  }
    
  return return_value;
}


#endif

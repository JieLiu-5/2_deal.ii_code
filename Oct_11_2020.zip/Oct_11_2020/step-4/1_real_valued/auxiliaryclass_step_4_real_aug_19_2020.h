
#ifndef AUXILIARYCLASS_STEP_4_REAL_H
#define AUXILIARYCLASS_STEP_4_REAL_H

/*
template <int dim>
class RightHandSide_Real:
public Function<dim>,
public Common_Var<dim>
{
public:
  using Common_Var<dim>::Common_Var;
  RightHandSide_Real (const unsigned int id_case, const double coeff_inner_x);
  
  const unsigned int id_case;
  const double coeff_inner_x;
  
  virtual double value (const Point<dim>   &p,
                        const unsigned int  component = 0) const;
};

template <int dim>
class PressureBoundaryValues_Real: 
public Function<dim>,
public Common_Var<dim>
{
public:
  using Common_Var<dim>::Common_Var;
  PressureBoundaryValues_Real (const unsigned int id_case, const double coeff_inner_x);
  
  const unsigned int id_case;
  const double coeff_inner_x;

  virtual double value (const Point<dim>   &p,
                        const unsigned int  component = 0) const;
};*/

template <int dim>
class ExactSolution_Step_4_Real:
public Function<dim>,
public Common_Var<dim>
{
public:
  using Common_Var<dim>::Common_Var;
  ExactSolution_Step_4_Real (const unsigned int id_case, const double coeff_inner_x);
  
  const unsigned int id_case;
  const double coeff_inner_x;
  
  virtual double value (const Point<dim>   &p,
                        const unsigned int  component = 0) const;
  virtual Tensor<1,dim> gradient (const Point<dim>   &p,
                                  const unsigned int  component = 0) const;
  virtual SymmetricTensor<2,dim> hessian (const Point<dim>   &p,
                                  const unsigned int  component = 0) const;
};


template <int dim>
class Coeff_Diff_Step_4_Real:public Common_Var<dim>
{
public:
  using Common_Var<dim>::Common_Var;
  Coeff_Diff_Step_4_Real(const unsigned int id_case, const double coeff_inner_x);
  double value(const Point<dim> &p);               // d_L2_inte is passed by u_L2_inte
protected:
  const unsigned int id_case;
  const double coeff_inner_x;
};

template <int dim>
class Coeff_Helm_Step_4_Real:
public Common_Var<dim>                
{
public:
  using Common_Var<dim>::Common_Var;
  Coeff_Helm_Step_4_Real (unsigned int id_case, const double coeff_inner_x);            

  void value (const vector<Point<dim>> &p,
              Vector<double>   &values) const;
        
protected:
  const unsigned int id_case;
  const double coeff_inner_x;
};     


template <int dim>
class ComputeSurface_Step_4_Real : public DataPostprocessorScalar<dim>
{
public:
  ComputeSurface_Step_4_Real ();

  virtual
  void
  evaluate_scalar_field
  (const DataPostprocessorInputs::Scalar<dim> &inputs,
   std::vector<Vector<double> >               &computed_quantities) const;
};


template <int dim>
class ComputeVelocity1_Step_4_Real: 
public DataPostprocessorScalar<dim>
{
public:
  ComputeVelocity1_Step_4_Real ();

  virtual
  void
  evaluate_scalar_field
  (const DataPostprocessorInputs::Scalar<dim> &inputs,
   std::vector<Vector<double> >               &computed_quantities) const;
};


template <int dim>
class Compute2ndderivative1_Step_4_Real:
public DataPostprocessorScalar<dim>
{
public:
  Compute2ndderivative1_Step_4_Real ();

  virtual
  void
  evaluate_scalar_field
  (const DataPostprocessorInputs::Scalar<dim> &inputs,
   std::vector<Vector<double> >               &computed_quantities) const;
};














// template <int dim>
// RightHandSide_Real<dim>::RightHandSide_Real(const unsigned int id_case, const double coeff_inner_x):
// Common_Var<dim>(id_case),
// id_case(id_case),
// coeff_inner_x(coeff_inner_x)
// {}
// 
// template <int dim>
// PressureBoundaryValues_Real<dim>::PressureBoundaryValues_Real(const unsigned int id_case, const double coeff_inner_x):
// Common_Var<dim>(id_case),
// id_case(id_case),
// coeff_inner_x(coeff_inner_x)
// {}

template <int dim>
ExactSolution_Step_4_Real<dim>::ExactSolution_Step_4_Real(const unsigned int id_case, const double coeff_inner_x):
Common_Var<dim>(id_case),
id_case(id_case),
coeff_inner_x(coeff_inner_x)
{}


template <int dim>
Coeff_Diff_Step_4_Real<dim>::Coeff_Diff_Step_4_Real(const unsigned int id_case, const double coeff_inner_x):
Common_Var<dim>(id_case),
id_case(id_case),
coeff_inner_x(coeff_inner_x)
{}

template <int dim>
Coeff_Helm_Step_4_Real<dim>::Coeff_Helm_Step_4_Real (unsigned int id_case, const double coeff_inner_x):
Common_Var<dim>(id_case),
id_case(id_case),
coeff_inner_x(coeff_inner_x)
{} 




// template <int dim>
// double RightHandSide_Real<dim>::value (const Point<dim> &p,
//                                   const unsigned int /*component*/) const
// {
//   double return_value = 0.0;
//   switch(id_case)
//   {
//     case 1:
//       return_value=sin(2.0*pi*coeff_inner_x*p[0]);
//       break;
//     case 2:
//       return_value=-exp(-coeff_inner_x*std::pow(p[0]-0.5,2))*(std::pow(2*coeff_inner_x*(p[0]-0.5),2)-2.0*coeff_inner_x);     // including benchmark Poisson
//       break;
//     case 3:
//       return_value=sin(2.0*pi*coeff_inner_x*p[0])+1.0;
//       break;
//     case 4:
//       return_value=2.0*pi*coeff_inner_x*sin(2.0*pi*coeff_inner_x*p[0]);
//       break;
//     case 5:
//       return_value=0.0;
//       break;
// 
//           
//                                                                                                 
//     case 22:                                                                                  // diffusion equation, u=exp(-(x-0.5)^2), d=1+0.5sin(cx)
//       return_value=-exp(-pow(p[0]-this->center_x,2.0))*(0.5*coeff_inner_x*cos(coeff_inner_x*p[0])*(-2*(p[0]-0.5))+(1.0+0.5*sin(coeff_inner_x*p[0]))*(pow(2*(p[0]-this->center_x),2)-2.0));
//       break;
//     case 24:                                                                                  // diffusion equation, u=exp(-(x-0.5)^2), d=1+cx
//       return -exp(-pow(p[0]-this->center_x,2.0))*                               
//       (coeff_inner_x*(-2*(p[0]-0.5))                
//       +(1.0+coeff_inner_x*p[0])*(pow(2*(p[0]-this->center_x),2)-2.0));    
//       break;  
//     case 241:                                                                                 // diffusion equation, u=exp(-(x-0.5)^2), d=c
//       return -exp(-pow(p[0]-this->center_x,2.0))*                               
//       (coeff_inner_x*(pow(2*(p[0]-this->center_x),2)-2.0));    
//       break;  
//     case 25:                                                                                  // diffusion equation, u case 1, d constant
//       return_value=this->coeff_diff_inde*sin(2.0*pi/coeff_inner_x*p[0]);
//       break;          
//     case 26:                                                                                  // diffusion equation, u=sin(2pix), d=1+cx
//       return_value=-2*pi*(coeff_inner_x*cos(2*pi*p[0])+(1.0+coeff_inner_x*p[0])*(-2*pi*sin(2*pi*p[0])));            // note: id_scaling==2 was used for this case, that is, scale L2 norm of d(x) to 1, July 22, 2020
//       break;
//           
//           
//     case 8:                                                                                   // Helmholtz equation
//       return_value=exp(-pow(p[0]-this->center_x,2.0))                                                 // p = exp(-(x-0.5)^2), d=1+0.5sin(x), r = c
//                    *(-(0.5*this->coeff_diff_inde*cos(this->coeff_diff_inde*p[0])*(-2*(p[0]-0.5))+(1.0+0.5*sin(this->coeff_diff_inde*p[0]))*(pow(2*(p[0]-this->center_x),2)-2.0))+coeff_inner_x);                  
//         // 
//       break;
//     case 80:
//       return_value=exp(-pow(p[0]-this->center_x,2.0))*coeff_inner_x;                                  // p = exp(-(x-0.5)^2), d=0, r = c
//       break;  
//     case 81:
//       return_value=exp(-pow(p[0]-this->center_x,2.0))
//                    *(-(pow(2*(p[0]-this->center_x),2)-2.0)*1.0        // p = exp(-(x-0.5)^2), d = 1.0, r = c
//                    + coeff_inner_x);
//       break;
//     case 82:
//       return_value=exp(-pow(p[0]-this->center_x,2.0))
//                    *(-(pow(2*(p[0]-this->center_x),2)-2.0)*1.0        // p = exp(-(x-0.5)^2), d = 1.0, r = 1+cx
//                    + 1.0+coeff_inner_x*p[0]);
//       break;
//     case 83:
//       return_value=exp(-pow(p[0]-this->center_x,2.0))
//                    *(-(pow(2*(p[0]-this->center_x),2)-2.0)*1.0        // p = exp(-(x-0.5)^2), d = 1.0, r = 1+sin(cx)
//                    + 1.0+sin(coeff_inner_x*p[0]));
//       break;
//     case 9:
//       return_value = exp(-pow(p[0]-this->center_x,2))*(2.0*(p[0]-this->center_x));                     // first-order differential equations
//       break;                                                                                           // not successful, Aug 11, 2020
//     default:
//       cout << "case does not exist" << endl;
//       throw exception();
//   }
//   return return_value;
// }


// template <int dim>
// double PressureBoundaryValues_Real<dim>::value (const Point<dim> &p,
//                                    const unsigned int /*component*/) const
// {
//   switch (id_case)
//   {
//     case 1:
//       return pow(2.0*pi*coeff_inner_x, -2.0)*sin(2.0*pi*coeff_inner_x*p[0]);
//       break;
//     case 2:
//       return exp(-coeff_inner_x*std::pow(p[0]-0.5,2));
//       break;
//     case 3:
//       return std::pow(2.0*pi*coeff_inner_x,-2)*sin(2.0*pi*coeff_inner_x*p[0])-std::pow(p[0],2)/2.0;
//       break;
//     case 4:
//       return pow(2.0*pi*coeff_inner_x, -1.0)*sin(2.0*pi*coeff_inner_x*p[0]);
//       break;
//     case 5:
//       return pow(coeff_inner_x, -1.0)*p[0];
//       break;
//         
//     case 22:
//     case 24:
//     case 241:
//       return exp(-std::pow((p[0]-this->center_x),2));
//       break;  
//     case 25:
//       return 1.0/((2.0*pi/coeff_inner_x)*(2.0*pi/coeff_inner_x))*sin(2.0*pi/coeff_inner_x*p[0]);
//       break;                
//     case 26:
//       return sin(2.0*pi*p[0]);
//       break;
//         
//     case 8:
//     case 80:
//     case 81:
//     case 82:
//     case 83:
//     case 9:
//       return exp(-std::pow((p[0]-this->center_x),2));
//       break;              
//     default:
//       cout << "case does not exist" << endl;
//       throw exception();
//   }
//   return 0;
// }


    
template <int dim>
double Coeff_Diff_Step_4_Real<dim>::value(const Point<dim> &p)
{
  double return_value=1.0;
  switch (id_case)
  {
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 9:
      break;
    case 8:
      return_value = 1.0+0.5*sin(p[0]);
      break;
    case 80:
      return_value=0.0;
      break;
    case 81:
    case 82:
    case 83:
      return_value = 1.0;
      break;
        
        
    case 22:
      return_value = 1.0+0.5*sin(coeff_inner_x*p[0]);
      break;
    case 24:
      return_value = 1.0 + coeff_inner_x*p[0];
      break;            
    case 241:
      return_value = coeff_inner_x;
      break;            
    case 25:
      return_value = this->coeff_diff_inde;
      break;            
    case 26:
      return_value = p[0]*coeff_inner_x+1.0;
      break;

    
    default:
      cout << "case does not exist" << endl;
      throw exception();             
  }
  return return_value;
}

template <int dim>
void
Coeff_Helm_Step_4_Real<dim>::value (const vector<Point<dim>> &p,
                    Vector<double> &values) const
{
  for(unsigned int i=0; i<values.size(); ++i)
  {
    switch (id_case)
    {
      case 8:
      case 80:
      case 81:
        values[i] = coeff_inner_x;
        break;
      case 82:
        values[i] = 1.0+coeff_inner_x*p[i][0];
        break;        
      case 83:
        values[i] = 1.0+sin(coeff_inner_x*p[i][0]);
        break;  
//             default:
//                 values[i] = 0.0;
//                 break;
//                 cout << "not a Helmholtz equation" << endl;
//                 throw exception();                   
        }
  }
}


template <int dim>
double ExactSolution_Step_4_Real<dim> :: value (const Point<dim>   &p,
        					 const unsigned int ) const
{
  double return_value;
  switch (id_case)
  {
    case 1:
    case 25:
        return_value = pow(2.0*pi*coeff_inner_x, -2.0)*sin(2.0*pi*coeff_inner_x*p[0]);
        break;
    case 2:
        return_value = exp(-coeff_inner_x*std::pow(p[0]-0.5,2));  
        break;
    case 3:
        return_value = std::pow(2.0*pi*coeff_inner_x, -2.0)*sin(2.0*pi*coeff_inner_x*p[0])-std::pow(p[0],2)/2.0;
        break;
    case 4:
        return_value = pow(2.0*pi*coeff_inner_x, -1.0)*sin(2.0*pi*coeff_inner_x*p[0]);
        break;
    case 5:
        return_value = pow(coeff_inner_x, -1.0)*p[0];
        break;
    case 22:
    case 24:
    case 241:
    case 8:
    case 80:
    case 81:
    case 82:
    case 83:
    case 9:
        return exp(-std::pow((p[0]-this->center_x),2));
        break;                 
        
    case 26:
        return_value = sin(2.0*pi*p[0]);
        break;
        
    default:
        cout << "case does not exist" << endl;
        throw exception();
  }
    
  return return_value;
}

template <int dim>
Tensor<1,dim> ExactSolution_Step_4_Real<dim>::gradient (const Point<dim>   &p,
                                       const unsigned int) const
{
  Tensor<1,dim> return_value;

  switch (id_case)
  {
    case 1:
    case 25:
      return_value[0] = pow(2.0*pi*coeff_inner_x, -1.0)*cos(2.0*pi*coeff_inner_x*p[0]);
      break;
    case 2:
      return_value[0] = std::exp(-coeff_inner_x*std::pow(p[0]-0.5,2))*(-2.0*coeff_inner_x*(p[0]-0.5));
      break;
    case 3:
      return_value[0] = pow(2.0*pi*coeff_inner_x, -1.0)*cos(2.0*pi*coeff_inner_x*p[0])-p[0];
      break;
    case 4:
      return_value[0] = cos(2.0*pi*coeff_inner_x*p[0]);
      break;
    case 5:
      return_value[0] = pow(coeff_inner_x, -1.0);
      break;
    case 22:
    case 24:
    case 241:
    case 8:
    case 80:
    case 81:
    case 82:
    case 83:
    case 9:
      return_value[0] = std::exp(-pow(p[0]-this->center_x,2))*(-2.0*(p[0]-this->center_x));
      break;              
        
    case 26:
      return_value[0] = 2.0*pi*cos(2.0*pi*p[0]);
      break;
        
    default:
      cout << "case does not exist" << endl;
      throw exception();              
  }
  
  return return_value;
}

template <int dim>
SymmetricTensor<2,dim> ExactSolution_Step_4_Real<dim>::hessian (const Point<dim>   &p,
                                       const unsigned int) const
{
  SymmetricTensor<2,dim> return_value;
  switch (id_case)
  {
    case 1:
    case 25:
      return_value[0][0] = -sin(2.0*pi*coeff_inner_x*p[0]);
      break;
    case 2:
      return_value[0][0] = exp(-coeff_inner_x*std::pow(p[0]-0.5,2))*(std::pow(2*coeff_inner_x*(p[0]-0.5),2)-2.0*coeff_inner_x);                      //dp/dx
      break;
    case 3:
      return_value[0][0] = -(sin(2.0*pi*coeff_inner_x*p[0])+1.0);
      break;
    case 4:
      return_value[0][0] = -2.0*pi*coeff_inner_x*sin(2.0*pi*coeff_inner_x*p[0]);
      break;
    case 5:
      return_value[0][0] =  0.0;
      break;
    case 22:
    case 24:
    case 241:
    case 8:
    case 80:
    case 81:
    case 82:
    case 83:
    case 9:
      return_value[0][0] = exp(-(p[0]-this->center_x)*(p[0]-this->center_x))*(pow(2*(p[0]-this->center_x),2)-2.0);                      //dp/dx
      break;              
        
    case 26:
      return_value[0][0] = -pow(2*pi,2.0)*sin(2.0*pi*p[0]);        // -2*pi*(coeff_inner_x*cos(2*pi*p[0])+(1.0+coeff_inner_x*p[0])*(-2*pi*sin(2*pi*p[0]))); 
      break;
        
    default:
      cout << "case does not exist" << endl;
      throw exception();              
  }
    
  return return_value;
}




template <int dim>
ComputeSurface_Step_4_Real<dim>::ComputeSurface_Step_4_Real ()
:
  DataPostprocessorScalar<dim> ("",        // solution
		  update_gradients)
{}

template <int dim>
void
ComputeSurface_Step_4_Real<dim>::evaluate_scalar_field
(const DataPostprocessorInputs::Scalar<dim> &inputs,
 std::vector<Vector<double> >               &computed_quantities) const
{
  for (unsigned int i=0; i<inputs.solution_values.size(); i++)
  {
    computed_quantities[i] = inputs.solution_values[i];
  }
}

template <int dim>
ComputeVelocity1_Step_4_Real<dim>::ComputeVelocity1_Step_4_Real ()
:
  DataPostprocessorScalar<dim> ("",    // gradient
		  update_gradients)
{}

template <int dim>
void
ComputeVelocity1_Step_4_Real<dim>::evaluate_scalar_field
(const DataPostprocessorInputs::Scalar<dim> &inputs,
 std::vector<Vector<double> >               &computed_quantities) const
{
  for (unsigned int i=0; i<inputs.solution_values.size(); i++)
  {
    computed_quantities[i](0) = inputs.solution_gradients[i][0];
  }
}

template <int dim>
Compute2ndderivative1_Step_4_Real<dim>::Compute2ndderivative1_Step_4_Real ()
:
  DataPostprocessorScalar<dim> ("",    // secondderivative
		  update_hessians)
{}

template <int dim>
void
Compute2ndderivative1_Step_4_Real<dim>::evaluate_scalar_field
(const DataPostprocessorInputs::Scalar<dim> &inputs,
 std::vector<Vector<double> >               &computed_quantities) const
{
  for (unsigned int i=0; i<inputs.solution_values.size(); i++)
  {
    computed_quantities[i](0) = inputs.solution_hessians[i][0][0];
  }
}


#endif

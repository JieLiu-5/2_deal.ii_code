
#ifndef MAINCLASS_STEP_4_REAL_H
#define MAINCLASS_STEP_4_REAL_H

#include <deal.II/fe/fe_q_hierarchical.h>

#include <deal.II/grid/grid_refinement.h>       
#include <deal.II/numerics/error_estimator.h>


#include <1_real_valued/auxiliaryclass_step_4_real.h>
// #include <1_real_valued/auxiliaryclass_step_4_real_2d.h>

// #include <gismo.h>
// #include <test_gismo.h>

template <int dim>
class Step4_Real                     
{
public:
  Step4_Real (const unsigned int id_case, const int id_quad_assem_incre, const double coeff_inner, const double tol_prm, const unsigned int degree, const unsigned int refine);
  
  void run ();
  
  const unsigned int   id_case;
  const int   id_quad_assem_incre;
  const double coeff_inner;
  const double tol_prm = 1e-16;
  const unsigned int   degree;
  const unsigned int   refine;                          
  
private:
  void make_grid ();
  void setup_system();
  void assemble_system ();
  void solve ();
  void compute_integrals();
  void compute_errors_built_in ();
  void compute_errors_custom ();
  void print_integrals_errors_and_CPU();
  void refine_grid ();
  void output_results () const;                         
  void store_error_cpu_time_to_file();                  

  const int n_vertices_custom;                          
  int cycle_global;                                     

  unsigned int is_mesh_built_in=1;
  
  Triangulation<dim>   triangulation;
  Triangulation<dim>   triangulation_first_refine; 
  
  unsigned int id_cell = 0;
  
  unsigned int is_neumann = 1;
  
  unsigned int id_basis = 0;
  unsigned int n_dofs_bspline = 1;
  
  FE_Q<dim>            fe;                  // _Q   _Bernstein   _Hierarchical         
                                            // basis functions make a difference to system_matrix
                                            
  unsigned int is_basis_extracted=0;

//   FEValues<dim> test_fe_values;          // not possible, July 22, 2020
  
  DoFHandler<dim>      dof_handler;
  DoFHandler<dim>      dof_handler_first_refine;

  SparsityPattern      sparsity_pattern;
  SparseMatrix<double> system_matrix;
  Vector<double>       system_rhs;
  
  Vector<double>       solution;
  Vector<double>       solution_first_refine;
  
  Vector<double>       solution_0;  
  
  ConstraintMatrix      constraints;
  
  unsigned int is_receiving_iga=0;
  
  string obj_string;
  
  QGauss<dim> quadrature_formula = QGauss<dim>(degree+id_quad_assem_incre);
  const unsigned int n_q_points = quadrature_formula.size();
  
  unsigned int is_strong = 1;
  double prm_penalty_weak = 1e6;                    // 1e6 50
  
  unsigned int is_matrices_before_BC_printed = 0;
  unsigned int is_matrices_after_BC_printed = 0;
  
  unsigned int is_matrix_after_BC_stored = 0;
  unsigned int is_rhs_after_BC_stored = 0;
  
  unsigned int is_UMFPACK = 1;
  unsigned int CG_iteration_times = 1;
  
  unsigned int is_solution_printed = 0;
  
  QGauss<dim> qgauss_integrate_difference = QGauss<dim>(degree+1);
  
  unsigned int is_integral_of_special_interest_computed = 0;
  
  unsigned int is_custom_method_used_for_error = 1;
  
  double u_L2_inte_analytical, H1_N, H2_N = 1.0;
  double L2_error, H1_semi_error, H2_semi_error;
  double L2_error_custom;
  double r_N, r_Np, r_Npp;
  
  double u_L2_inte_numerical;
  double u_mean_inte_numerical, u_mean_inte_analytical;
  
  double f_L2_inte_numerical, f_L2_inte_analytical=0;
  
  unsigned int is_results_stored=0;
  
  unsigned int n_components_number = 1;
  
  TimerOutput          computing_timer;
  double total_CPU_time;
  
  unsigned int is_L2_norm_stored = 0;
  unsigned int is_solver_info_stored = 1;  
};


template <int dim>
void Step4_Real<dim>::store_error_cpu_time_to_file()
{
  cout << "Storing errors and cpu time to a file" << endl;
  ofstream myfile;    
  myfile.open ("data_error_oned_sm.txt", ofstream::app);
  myfile << refine << " ";             
#if 1 
  myfile << triangulation.n_vertices() <<" ";
  myfile << dof_handler.n_dofs() << " ";
  myfile << L2_error << " ";
  myfile << H1_semi_error << " ";
  myfile << H2_semi_error << " ";
  myfile << total_CPU_time << " ";
    
  if (is_L2_norm_stored == 1)
  {
    myfile << u_L2_inte_analytical << "\n";
  }
  if (is_solver_info_stored == 1)
  {
    if (is_UMFPACK == 1)
    {
      myfile << "UMF" << "\n";
    }else if (is_UMFPACK == 0)
    {
      myfile << CG_iteration_times << "\n";
    }
  }
#endif
  myfile.close();
}



template <int dim>
Step4_Real<dim>::Step4_Real (const unsigned int id_case, const int id_quad_assem_incre, const double coeff_inner, const double tol_prm, const unsigned int degree, const unsigned int refine)
  :
  id_case(id_case),
  id_quad_assem_incre(id_quad_assem_incre),
  coeff_inner(coeff_inner),
  tol_prm(tol_prm),
  degree(degree),
  refine(refine),
  n_vertices_custom(refine),
  fe (degree),
  dof_handler (triangulation),
  dof_handler_first_refine (triangulation_first_refine),
  computing_timer  (cout, TimerOutput::summary, TimerOutput::cpu_times)
{
    cout << "================== \n"
         << "  The standard FEM for real-valued problems\n"
         << "  dimension: " << dim << "\n"
         << "  n_q_points: " << n_q_points 
         << endl;    
    cout << "================== " << endl;
}


template <int dim>
void Step4_Real<dim>::make_grid ()
{
  cout << "Making grid" << endl;    
  TimerOutput::Scope t(computing_timer, "make_grid");
    
  if(is_mesh_built_in==1)
  {
    cout << "  mesh built_in\n";
    GridGenerator::hyper_cube (triangulation, 0, 1);
  }else if(is_mesh_built_in==0 && dim==1)
  {
    cout << "  mesh custom\n";                                                    // only for one-dimension
    cout << "  number of vertices: " << n_vertices_custom << "\n";
    vector<Point<dim>> vertices(n_vertices_custom);

    const double delta_vertex = 1.0/(n_vertices_custom-1);
    for (int i = 0; i < n_vertices_custom; ++i)
    {
      vertices[i](0) = i * delta_vertex;
    } 

    vector<array<int,GeometryInfo<dim>::vertices_per_cell>> cell_vertices;
    array<int,GeometryInfo<dim>::vertices_per_cell> array_update;
    for (int i = 0; i<n_vertices_custom-1; ++i)
    {
      array_update = {i,i+1};
      cell_vertices.push_back(array_update);
    }

    vector<CellData<dim>> cells(cell_vertices.size(), CellData<dim>());
    for (unsigned int i=0; i<cell_vertices.size(); ++i)
    {
      for (unsigned int j=0; j<GeometryInfo<dim>::vertices_per_cell; ++j)
      {
        cells[i].vertices[j] = cell_vertices[i][j];
      }
    }
    triangulation.create_triangulation (vertices, cells, SubCellData());  
  }else
  {
    cout << "  unavailable mesh scheme\n";
    exit(1);
  }
  
  print_tria_info(triangulation);
    
//   print_boundary_info(triangulation);
  
  if (is_neumann==0)
  {
    if (dim==1)
    {
      cout << "setting the rightest boundary as Dirichlet type" << endl;
      triangulation.begin_active()->face(1)->set_boundary_id(0);  
    }
  }else if (is_neumann==1)
  {
    if(dim==2)
    {
        adjust_boundary_id_2d(triangulation);
    }      
  }

  print_boundary_info(triangulation);
  
  if (is_mesh_built_in==1)
  {
    cout << "Refining mesh\n";
    triangulation.refine_global (refine);    
  }
  
  triangulation_first_refine.copy_triangulation(triangulation);
  dof_handler_first_refine.distribute_dofs (fe);                          // we only need one time of initialization of it, so we put it here
  
  
  if (id_basis==0)
  {
    print_dofs_info(dof_handler_first_refine);
  }else if(id_basis==1)
  {
    n_dofs_bspline = degree+pow(2,refine);
    cout << n_dofs_bspline;
  }
  
}

    



template <int dim>
void Step4_Real<dim>::setup_system ()
{
  TimerOutput::Scope t(computing_timer, "setup_system");
  cout << "Setting up the system " << endl; 
  
  dof_handler.distribute_dofs (fe);
  
//   Tensor<1,1> direction;
//   direction[0]=1;
//   cout << direction << "\n";
//   DoFRenumbering::downstream(dof_handler,direction);
  

  DynamicSparsityPattern dsp(dof_handler.n_dofs());
  
  DoFTools::make_sparsity_pattern (dof_handler, dsp);               // dispensing non-zero entries

  sparsity_pattern.copy_from(dsp);

  system_matrix.reinit (sparsity_pattern);

  solution.reinit (dof_handler.n_dofs());
  solution_0.reinit (dof_handler.n_dofs());
  
  system_rhs.reinit (dof_handler.n_dofs());
  
}

template <int dim>
void Step4_Real<dim>::assemble_system ()
{
  cout << "Assembling the system " << endl;
  TimerOutput::Scope t(computing_timer, "assemble_system");
  QGauss<dim-1> face_quadrature_formula(degree+2);   
  
  Coeff_Diff_Final_Real<dim> coeff_diff_final_real(id_case, coeff_inner);
  const Coeff_Helm_Real<dim> coeff_helm_real(id_case, coeff_inner); 
  const RightHandSide_Real<dim> right_hand_side(id_case, coeff_inner);

  FEValues<dim> fe_values (fe, quadrature_formula,
                           update_values   | update_gradients | update_hessians |
                           update_quadrature_points | update_JxW_values | update_jacobians);
  FEFaceValues<dim> fe_face_values (fe, face_quadrature_formula,
                                    update_values         | update_quadrature_points  |
                                    update_normal_vectors | update_JxW_values);
  
  const unsigned int   dofs_per_cell = fe.dofs_per_cell;
  const unsigned int n_face_q_points = face_quadrature_formula.size();
  
  Vector<double> coeff_diff_values (n_q_points);
  Vector<double> coeff_helm_values (n_q_points);
  
  FullMatrix<double>   cell_matrix (dofs_per_cell, dofs_per_cell);
  Vector<double>       cell_rhs (dofs_per_cell);

  vector<types::global_dof_index> local_dof_indices (dofs_per_cell);

  const ExactSolution_Step_4_Real<dim> exact_solution(id_case, coeff_inner);  
  
  typename DoFHandler<dim>::active_cell_iterator
  cell = dof_handler.begin_active(),
  endc = dof_handler.end();
  
  id_cell=0;
  
  for (; cell!=endc; ++cell)
  {
    fe_values.reinit (cell);
    cell_matrix = 0;
    cell_rhs = 0;
    
    id_cell++;
    
//     cout << "  cell " << cell->active_cell_index() << endl;
      
/*    for (unsigned int vertex=0; vertex < GeometryInfo<dim>::vertices_per_cell; ++vertex)
    {
      cout << "      at vertex " << cell->vertex_index(vertex) << ", coords: " << cell->vertex(vertex) << "\n";
    }
    cout << endl; */     
    
    coeff_diff_final_real.value (fe_values.get_quadrature_points(), coeff_diff_values);
    coeff_helm_real.value (fe_values.get_quadrature_points(), coeff_helm_values);

//     cout  << "  jacobian: " << fe_values.jacobian(0)[0] << "\n";                                      // jacobians of each quadrature point are the same
//     cout  << "  coordinates: ";
//     for (unsigned int q_index=0; q_index<n_q_points; ++q_index)
//     {
//         cout << fe_values.quadrature_point(q_index)(0) << " ";
//     }    
//     cout << "\n";    
//     cout  << "  JxW: ";
//     for (unsigned int q_index=0; q_index<n_q_points; ++q_index)
//     {
//         cout << fe_values.JxW (q_index) << " ";
//     }    
//     cout << "\n";
    
//     cout << "values\n";
//     for (unsigned int i=0; i<dofs_per_cell; ++i)
//     {
//         cout << "basis " << i << ": ";
//         for (unsigned int q_index=0; q_index<n_q_points; ++q_index)
//         {
//           cout << fe_values.shape_value (i, q_index) << " ";                  // 
//         }
//         cout << "\n";
//     }
//     
//     cout << "gradients\n";
//     for (unsigned int i=0; i<dofs_per_cell; ++i)
//     {
//         cout << "basis " << i << ": ";
//         for (unsigned int q_index=0; q_index<n_q_points; ++q_index)
//         {
//           cout << fe_values.shape_grad (i, q_index) << " ";                  // gradients update according to jacobian, while values do not, cf. transformation from original coordinates to reference coordinates
//         }
//         cout << "\n";
//     }
    
#if 0    
    unsigned int n_rows = 3;
    unsigned int n_cols = 3;
  
    vector<vector<double>> data_value(n_rows);
    vector<vector<double>> data_gradient(n_rows);
    for (unsigned int i = 0 ; i < n_rows; i++)
    {
      data_value[i].resize(n_cols);  
      data_gradient[i].resize(n_cols);  
    }

    cout << "\n";
    cout << "reading data of isogeometric analysis\n";
    ifstream fid_value;
    fid_value.open("basis_bspline/"+to_string(refine+1)+"_refine_"+to_string(refine)+"/bspline_fe_values_"+to_string(id_cell)+".txt");
    ifstream fid_gradient;
    fid_gradient.open("basis_bspline/"+to_string(refine+1)+"_refine_"+to_string(refine)+"/bspline_fe_gradients_"+to_string(id_cell)+".txt");
  
    for (unsigned int i = 0 ; i < n_rows; ++i)
    {
      for (unsigned int j = 0; j < n_cols; ++j)
      {  
        fid_value >> data_value[i][j];  
        fid_gradient >> data_gradient[i][j];
        
//         if (i==0)
//         {
//           fid_value >> data_value[i][j];  
//           fid_gradient >> data_gradient[i][j];    
//         }else if (i==1)
//         {
//           fid_value >> data_value[2][j];  
//           fid_gradient >> data_gradient[2][j];  
//         }else if (i==2)
//         {
//           fid_value >> data_value[1][j];  
//           fid_gradient >> data_gradient[1][j];
//         }
      }
    }  
    fid_value.close();
    fid_gradient.close();

    cout << "data_value: \n";
    for (unsigned int i=0; i<data_value.size(); ++i)
    {
      cout << "basis " << i << ": ";
      for (unsigned int j = 0; j < n_cols; ++j)
      {    
        cout << data_value[i][j] << " ";
      }
      cout << "\n";
    }
  
    cout << "data_gradient: \n";
    for (unsigned int i=0; i<data_gradient.size(); ++i)
    {
      cout << "basis " << i << ": ";
      for (unsigned int j = 0; j < n_cols; ++j)
      {    
        cout << data_gradient[i][j] << " ";
      }
      cout << "\n";
    }
    
#endif
      
    for (unsigned int q_index=0; q_index<n_q_points; ++q_index)
    {
      for (unsigned int i=0; i<dofs_per_cell; ++i)
      {   
        for (unsigned int j=0; j<dofs_per_cell; ++j)
        {
          if (id_case!=9)                          // the order of the operation seems not optimal, but we use it because we've already used it for Poisson and diffusion equations
          {
//             if (id_basis==0)
//             {
              cell_matrix(i,j) += (fe_values.shape_grad (i, q_index) * fe_values.shape_grad (j, q_index) * fe_values.JxW (q_index) * coeff_diff_values[q_index]
                                  + fe_values.shape_value (i, q_index) * fe_values.shape_value (j, q_index) * fe_values.JxW (q_index) * coeff_helm_values[q_index]);  
//             }else if(id_basis==1)
//             {
// //               cell_matrix(i,j) += (data_gradient [i][q_index] * data_gradient [j][q_index]) * fe_values.JxW (q_index) * coeff_diff_values[q_index]);
//             }
              
              
          }
          
          if(id_case==9)                           // dealing with first-order differential equations
          {
            cell_matrix(i,j) -= fe_values.shape_value (i, q_index) *
                             fe_values.shape_grad (j, q_index)[0] *
                             fe_values.JxW (q_index);
          } 
        }
        
//         if (id_basis==0)
//         {
          cell_rhs(i) += (fe_values.shape_value (i, q_index) *
                          right_hand_side.value (fe_values.quadrature_point (q_index)) *
                          fe_values.JxW (q_index));
//         }else if(id_basis==1)
//         {
//           cell_rhs(i) += (data_value[i][q_index] *
//                           right_hand_side.value (fe_values.quadrature_point (q_index)) *
//                           fe_values.JxW (q_index));  
//         }
      }
    }
    
//     cout << "the resulting cell_matrix: \n";
//     cell_matrix.print(cout, 5);
//     cout << "the resulting cell_rhs: \n";
//     cell_rhs.print(cout, 5);
    
    
      
    for (unsigned int face_n=0; face_n<GeometryInfo<dim>::faces_per_cell; ++face_n)
    {
      if (cell->face(face_n)->at_boundary() && (cell->face(face_n)->boundary_id() == 1))                                  //treat the Neumann boundary conditions
      {
//         cout  << "  Imposing Neumann boundaries on ";
//         cout << "cell " << cell->active_cell_index() << " (" << cell->vertex(0) << ", " << cell->vertex(dim==1?1:3) << "), ";                
//         cout << "face " << face_n << " ";   
//         for (unsigned int vertex=0; vertex < GeometryInfo<dim>::vertices_per_face; ++vertex)
//         {
//           cout << "(" << cell->face(face_n)->vertex(vertex) << ")";
//         }
//         cout << endl;
             
        fe_face_values.reinit (cell, face_n);
        
/*        cout << "fe_face_values\n";
        for (unsigned int i=0; i<dofs_per_cell; ++i)
        {
            cout << "basis " << i << ": ";
            for (unsigned int q_index=0; q_index<n_face_q_points; ++q_index)
            {
            cout << fe_face_values.shape_value (i, q_index) << " ";
            }
            cout << "\n";
        }  */       

        for (unsigned int q_point=0; q_point<n_face_q_points; ++q_point)
        {
          const double neumann_value
          = (exact_solution.gradient (fe_face_values.quadrature_point(q_point)) *
            fe_face_values.normal_vector(q_point));
          
            

          for (unsigned int i=0; i<dofs_per_cell; ++i)
          {
            cell_rhs(i) += (neumann_value *
                           fe_face_values.shape_value(i,q_point) *
                           fe_face_values.JxW(q_point)*coeff_diff_values[q_point]);              // (1+coeff_inner)/(id_scaling==2?coeff_inner:1.0)
          }
        }
      }
    }
      
    cell->get_dof_indices (local_dof_indices);
    
//     cout << "\n";
//     cout << "local_dof_indices: ";
//     for (unsigned int i=0; i<dofs_per_cell; ++i)
//     {
//       cout << local_dof_indices[i] << " ";
//     }
//     cout << "\n";
    
    
    if (id_basis==0)
    {
      for (unsigned int i=0; i<dofs_per_cell; ++i)
      {
//         cout << "[" << i << "] " << local_dof_indices[i] << "\n";
        for (unsigned int j=0; j<dofs_per_cell; ++j)
        {
//           cout << "[" << j << "] " << local_dof_indices[j] << "\n";
        
//           cout << "cell_matrix(" << i << "," << j << "): " << cell_matrix(i,j) << "\n";
        
          system_matrix.add (local_dof_indices[i],
                             local_dof_indices[j],
                             cell_matrix(i,j));
        }
//         cout << "\n";

        system_rhs(local_dof_indices[i]) += cell_rhs(i);
      }  
    }else if(id_basis==1)
    {
      for (unsigned int i=0; i<dofs_per_cell; ++i)
      {
        
//         cout << "[" << i << "] " << local_dof_indices[i] << "\n";
        for (unsigned int j=0; j<dofs_per_cell; ++j)
        {
//           cout << "[" << j << "] " << local_dof_indices[j] << "\n";
        
//           cout << "cell_matrix(" << i << "," << j << "): " << cell_matrix(i,j) << "\n";
        
          system_matrix.add (local_dof_indices[i],
                             local_dof_indices[j],
                             cell_matrix(i,j));
        }
//         cout << "\n";

        system_rhs(local_dof_indices[i]) += cell_rhs(i);
      }
    
//       cout  << "\n";  
//     
//       cout << "system_matrix after cell " << id_cell << endl;
//       system_matrix.print_formatted(cout);
//       cout << '\n';
//       cout << "system_rhs after cell " << id_cell << endl;
//       system_rhs.print(cout,5);
    }
  }

  if (is_matrices_before_BC_printed==1)
  {
    cout << "system_matrix before applying BC is " << endl;
    system_matrix.print_formatted(cout);
    cout << '\n';
    cout << "system_rhs before applying BC is " << endl;
    system_rhs.print(cout,5);
  }    

  cout << "  Imposing Dirichlet boundary conditions\n";
  if (is_strong == 1)
  {
    cout << "    strong way\n";
    map<types::global_dof_index,double> boundary_values;
    VectorTools::interpolate_boundary_values (dof_handler,
                                              0,
                                              PressureBoundaryValues_Real<dim>(id_case, coeff_inner),
                                              boundary_values);

    MatrixTools::apply_boundary_values (boundary_values,
                                        system_matrix,
                                        solution,
                                        system_rhs);
    
  }else if (is_strong == 0)
  {
    cout << "    weak way\n";
    PressureBoundaryValues_Real<dim> boundary_values_for_weak(id_case, coeff_inner);  
    
    vector<Point<dim>> coords_quad_boundary(2);
    coords_quad_boundary[0](0)=0.0;
    coords_quad_boundary[1](0)=1.0;
    
    FEValues<dim> fe_values_boundary (fe, coords_quad_boundary,
                             update_values   | update_gradients | update_quadrature_points );
  
    dof_handler.distribute_dofs (fe);  
    
    typename DoFHandler<dim>::active_cell_iterator 
    first_cell = dof_handler.begin_active(), 
    intermediate_cell = dof_handler.begin_active(),
    last_cell = dof_handler.begin_active();
  
    fe_values_boundary.reinit(first_cell);
    first_cell->get_dof_indices (local_dof_indices);

    if (first_cell->face(0)->boundary_id() == 0) 
    { 
      for (unsigned int j=0; j<dofs_per_cell; ++j)                            // 
      {
        system_matrix.add (local_dof_indices[0],
                            local_dof_indices[j],
                            fe_values_boundary.shape_grad(j,0)[0]);
        system_matrix.add (local_dof_indices[j],
                           local_dof_indices[0],
                            -fe_values_boundary.shape_grad(j,0)[0]);  
        system_matrix.add (local_dof_indices[0], local_dof_indices[0], prm_penalty_weak);  
        
        system_rhs(local_dof_indices[j]) -= fe_values_boundary.shape_grad(j,0)[0]*boundary_values_for_weak.value(fe_values_boundary.quadrature_point(0)); 
        system_rhs(local_dof_indices[0]) += prm_penalty_weak*boundary_values_for_weak.value(fe_values_boundary.quadrature_point(0)); 
      }
    }

    for(unsigned int i = 0; i < triangulation.n_active_cells()-1; ++i)
    {
      ++intermediate_cell;
    }
  
    last_cell=intermediate_cell;
  
    fe_values.reinit (last_cell);
    last_cell->get_dof_indices (local_dof_indices);

    if (last_cell->face(1)->boundary_id() == 0)
    {
      for (unsigned int j=0; j<dofs_per_cell; ++j)
      {
        system_matrix.add (local_dof_indices[1],
                            local_dof_indices[j],
                            -fe_values_boundary.shape_grad(j,1)[0]);
        system_matrix.add (local_dof_indices[j],
                           local_dof_indices[1],
                            fe_values_boundary.shape_grad(j,1)[0]);  
        system_matrix.add (local_dof_indices[1], local_dof_indices[1], -prm_penalty_weak);  
        
        system_rhs(local_dof_indices[j]) += fe_values_boundary.shape_grad(j,1)[0]*boundary_values_for_weak.value(fe_values_boundary.quadrature_point(0)); 
        system_rhs(local_dof_indices[1]) -= prm_penalty_weak*boundary_values_for_weak.value(fe_values_boundary.quadrature_point(0)); 
      }
    }
  } else
  {
    cout << "  Dirichlet boundary conditions not treated\n";
  }

  if (is_matrices_after_BC_printed==1)
  {
    cout << "system_matrix after applying BC is " << endl;
    system_matrix.print_formatted(cout);
    cout << '\n';
    cout << "system_rhs after applying BC is " << endl;
    system_rhs.print(cout,5);
  }

  ostringstream streamObj;
  streamObj << fixed;
  streamObj << setprecision(0);
  streamObj << this->coeff_inner;
  
  if (is_matrix_after_BC_stored==1)
  {
    obj_string="system_matrix_coeff_"+ streamObj.str() +"_deg_"+to_string(degree)+"_ref_"+to_string(refine);
    save_system_matrix_to_txt(obj_string,system_matrix);
  }
  
  if(is_rhs_after_BC_stored==1)
  {
    obj_string="system_rhs_coeff_"+ streamObj.str() +"_deg_"+to_string(degree)+"_ref_"+to_string(refine);
    save_Vector_to_txt(obj_string,system_rhs);
  }
}


template <int dim>
void Step4_Real<dim>::solve ()
{
  TimerOutput::Scope t(computing_timer, "solve");
  cout << "Solving " << endl;

  if (tol_prm != 0)
  {
    is_UMFPACK = 0;
  }
    
  if (is_UMFPACK==1)          
  {
    cout << "  UMFPack solver " <<  endl;
    SparseDirectUMFPACK  A_direct;
    A_direct.initialize(system_matrix);
    A_direct.vmult (solution, system_rhs);
        
  }else if(is_UMFPACK==0)   
  {
    cout << "  CG solver, tol_prm: " << tol_prm << endl;
    SolverControl           solver_control (1e+8, tol_prm);
    SolverCG<>              solver (solver_control);
    solver.solve (system_matrix, solution, system_rhs,
                    PreconditionIdentity());
    CG_iteration_times = solver_control.last_step();
    cout << "  " << solver_control.last_step() << " CG iterations needed to obtain convergence." << endl;
  }
  cout << endl;
}


template <int dim>
void Step4_Real<dim>::compute_integrals ()
{
  cout << "Computing integrals " << endl;    
  const ZeroFunction<dim> zero_function;
  const RightHandSide_Real<dim> right_hand_side(id_case, coeff_inner);
  const ExactSolution_Step_4_Real<dim> exact_solution(id_case, coeff_inner);
    
  Vector<double> difference_per_cell (triangulation.n_active_cells());
  
  VectorTools::integrate_difference (dof_handler,                 // alternative: 1. the opposite of u_mean_inte_numerical: VectorTools::mean, VectorTools::mean   
                                   solution,                      //              2. f_L2_inte_numerical: solution -> system_rhs
                                   zero_function,
                                   difference_per_cell,
                                   qgauss_integrate_difference,
                                   VectorTools::L2_norm);
  u_L2_inte_numerical = VectorTools::compute_global_error(triangulation,
                                                          difference_per_cell,
                                                          VectorTools::L2_norm);    
    
    
    
    
  VectorTools::integrate_difference (dof_handler,                 // alternative : 1. f_L2_inte_analytical: exact_solution -> right_hand_side, VectorTools::L2_norm, VectorTools::L2_norm
                                   solution_0,
                                   exact_solution,
                                   difference_per_cell,
                                   qgauss_integrate_difference,
                                   VectorTools::mean);
  u_mean_inte_analytical = VectorTools::compute_global_error(triangulation,
                                                            difference_per_cell,
                                                            VectorTools::mean);
}

template <int dim>
void Step4_Real<dim>::compute_errors_built_in ()
{
  cout << "Computing errors using the built-in function" << endl;    
//   TimerOutput::Scope t(computing_timer, "compute_errors_built_in");
  ExactSolution_Step_4_Real<dim> exact_solution(id_case, coeff_inner);
  
  Vector<double> difference_per_cell (triangulation.n_active_cells());
  
  
  VectorTools::integrate_difference (dof_handler,
                                     solution_0,
                                     exact_solution,
                                     difference_per_cell,
                                     qgauss_integrate_difference,
                                     VectorTools::L2_norm);
  u_L2_inte_analytical = VectorTools::compute_global_error(triangulation,
                                                            difference_per_cell,
                                                            VectorTools::L2_norm);
  
//   cout << "  difference_per_cell\n";
//   cout << difference_per_cell;
  
#if 1
  VectorTools::integrate_difference (dof_handler,
                                    solution,
                                    exact_solution,
                                    difference_per_cell,
                                    qgauss_integrate_difference,
                                    VectorTools::L2_norm);
  L2_error = VectorTools::compute_global_error(triangulation,
                                                        difference_per_cell,
                                                           VectorTools::L2_norm);

  r_N = L2_error/u_L2_inte_analytical;
  
//   cout << "  difference_per_cell\n";
//   cout << difference_per_cell;  
  
 

  VectorTools::integrate_difference (dof_handler,
                                     solution_0,
                                     exact_solution,
                                     difference_per_cell,
                                     qgauss_integrate_difference,
                                     VectorTools::H1_seminorm);
  H1_N = VectorTools::compute_global_error(triangulation,
                                                            difference_per_cell,
                                                            VectorTools::H1_seminorm);

  VectorTools::integrate_difference (dof_handler,
                                     solution,
                                     exact_solution,
                                     difference_per_cell,
                                     qgauss_integrate_difference,
                                     VectorTools::H1_seminorm);
  H1_semi_error = VectorTools::compute_global_error(triangulation,
                                                            difference_per_cell,
                                                            VectorTools::H1_seminorm);

  r_Np = H1_semi_error/H1_N;



  VectorTools::integrate_difference (dof_handler,
                                     solution_0,
                                     exact_solution,
                                     difference_per_cell,
                                     qgauss_integrate_difference,
                                     VectorTools::H2_seminorm);
  H2_N = VectorTools::compute_global_error(triangulation,
                                                            difference_per_cell,
                                                            VectorTools::H2_seminorm);

  VectorTools::integrate_difference (dof_handler,
                                     solution,
                                     exact_solution,
                                     difference_per_cell,
                                     qgauss_integrate_difference,
                                     VectorTools::H2_seminorm);
  H2_semi_error = VectorTools::compute_global_error(triangulation,
                                                            difference_per_cell,
                                                            VectorTools::H2_seminorm);
  
  r_Npp = H2_semi_error/H2_N;
  
#endif

}


template <int dim>
void Step4_Real<dim>::compute_errors_custom ()
{
  cout << endl << "Computing errors using the custom function" << endl;

  solution_first_refine.reinit (dof_handler.n_dofs());
  solution_first_refine=solution;
  
  if (is_solution_printed == 1)
  {
    cout << "  solution reads ";
    solution.print(cout,5);
  }  
  
//     cout << "  solution_first_refine: ";
//     solution_first_refine.print(cout,5); 

  cout << "\n//////////////////\n";                             // computing the solution of the second refinement and extract the function values
    
  triangulation.refine_global ();
  setup_system ();
  assemble_system ();
  solve ();
  
//   cout << "solution_second_refine reads ";
//   solution.print(cout,5);   
  
  vector<double> vector_error(3);
  error_computation_custom_core(solution_first_refine, solution, dof_handler_first_refine, dof_handler, quadrature_formula, n_components_number,vector_error);
    
  cout << "//////////////////\n\n";
  
  
#if 1
  vector<double> solution_values_first_refine_at_quads_per_cell(n_q_points);
  vector<double> solution_values_second_refine_at_quads_per_cell(n_q_points);
  vector<double> solution_diff_at_quads_per_cell(n_q_points);
  
  double l2_error_per_cell = 0;
  Vector<double> cellwise_error(triangulation_first_refine.n_active_cells());
     
  int cell_index_first_refine = 0;  
  
  
  typename DoFHandler<dim>::active_cell_iterator  
  cell_iterator_first_refine = dof_handler_first_refine.begin_active();
//   endc_first_refine=dof_handler_first_refine.end();
  
  FEValues<dim> fe_values (fe, quadrature_formula,
                          update_values   | update_gradients | update_hessians |
                          update_quadrature_points | update_JxW_values);    
  
  
//   print_quadrature_info(quadrature_formula);
  
  vector<Point<dim> > quad_coords_vector=quadrature_formula.get_points();
  
//   obj_string="data_quad_coords";
//   save_vector_of_Point_to_txt(obj_string,quad_coords_vector);
  
//   cout << "  quad_coords_vector before scaling: \n";
//   print_vector(quad_coords_vector);
  
  
  
  
  
  if (dim==1)
  {
      
    unsigned int n_q_points_one_side = (n_q_points+1)/2.0;
    
    vector<Point<dim> > left_quad_vector(n_q_points_one_side);
    vector<Point<dim> > right_quad_vector(n_q_points_one_side);

    for (unsigned int i=0; i<left_quad_vector.size();++i)
    {
      left_quad_vector[i]=quad_coords_vector[i]*2;
    }
    
    for (unsigned int i=0; i<right_quad_vector.size();++i)
    {
      right_quad_vector[i](0) = (quad_coords_vector[i+(n_q_points_one_side*2==n_q_points?n_q_points_one_side:n_q_points_one_side-1)](0)-0.5)*2;
    }
    
//     cout << "  left_quad_vector: \n";
//     print_vector(left_quad_vector);    
//     cout << "  right_quad_vector: \n";
//     print_vector(right_quad_vector);
  
    Quadrature<dim>  quadrature_formula_high_2_low_left(left_quad_vector);
    FEValues<dim> fe_values_high_2_low_left (fe, quadrature_formula_high_2_low_left,
                            update_values   | update_gradients | update_hessians |
                            update_quadrature_points | update_JxW_values);
    
    Quadrature<dim>  quadrature_formula_high_2_low_right(right_quad_vector);                  
    FEValues<dim> fe_values_high_2_low_right (fe, quadrature_formula_high_2_low_right,
                            update_values   | update_gradients | update_hessians |
                            update_quadrature_points | update_JxW_values);    
                          
                          
    vector<double > solution_values_second_refine_at_quads_per_cell_left(n_q_points_one_side);                        // we need to separate them because we use them in different cells
    vector<double > solution_values_second_refine_at_quads_per_cell_right(n_q_points_one_side);                          
    vector<double > solution_values_second_refine_at_quads_per_cell(n_q_points);
    
    typename DoFHandler<dim>::active_cell_iterator
    cell = dof_handler.begin_active(),
    endc = dof_handler.end();   
  
    id_cell=0;
    for (; cell!=endc; ++cell)
    {
//       cout  << "  cell: " << id_cell++ << "\n";
      
      if (cell->active_cell_index()%2==0)
      {
//         cout << "  using fe_values_high_2_low_left\n";
        fe_values_high_2_low_left.reinit (cell);
/*        cout  << "  coordinates of quadrature points of fe_values_high_2_low_left: ";
        for (unsigned int q_index=0; q_index<n_q_points_one_side; ++q_index)
        {
          cout << fe_values_high_2_low_left.quadrature_point(q_index)(0) << " ";
        }    
        cout << "\n"; */      
      
        fe_values_high_2_low_left.get_function_values (solution, solution_values_second_refine_at_quads_per_cell_left);
      
        for (unsigned int i=0; i<solution_values_second_refine_at_quads_per_cell_left.size();++i)
        {
          solution_values_second_refine_at_quads_per_cell[i]=solution_values_second_refine_at_quads_per_cell_left[i];             
        }
        
      }else
      {
//         cout << "  using fe_values_high_2_low_right\n";
      
        fe_values_high_2_low_right.reinit (cell);
      
/*        cout  << "  coordinates of quadrature points of fe_values_high_2_low_right: ";
        for (unsigned int q_index=0; q_index<n_q_points_one_side; ++q_index)
        {
          cout << fe_values_high_2_low_right.quadrature_point(q_index)(0) << " ";
        }    
        cout << "\n";  */     
      
        fe_values_high_2_low_right.get_function_values (solution, solution_values_second_refine_at_quads_per_cell_right);
            
        if (2*n_q_points_one_side==n_q_points)
        {
          for (unsigned int i=0; i<solution_values_second_refine_at_quads_per_cell_right.size();++i)
          {
            solution_values_second_refine_at_quads_per_cell[n_q_points_one_side+i]=solution_values_second_refine_at_quads_per_cell_right[i];
          }  
        }else
        {
          for (unsigned int i=1; i<solution_values_second_refine_at_quads_per_cell_right.size();++i)
          {
            solution_values_second_refine_at_quads_per_cell[n_q_points_one_side+i-1]=solution_values_second_refine_at_quads_per_cell_right[i];
          }
        }
        
        fe_values.reinit (cell_iterator_first_refine);                                     // dealing with data of the first refinement
        fe_values.get_function_values (solution_first_refine, solution_values_first_refine_at_quads_per_cell);    
        
        cell_index_first_refine = cell_iterator_first_refine->active_cell_index();

        for (unsigned int q_index=0; q_index<n_q_points; ++q_index)
        {
            l2_error_per_cell += pow(solution_values_first_refine_at_quads_per_cell[q_index] - solution_values_second_refine_at_quads_per_cell[q_index],2 ) * fe_values.JxW (q_index) ;
        }
//         cout << "  l2_error_per_cell: " << l2_error_per_cell << "\n";
        cellwise_error[cell_index_first_refine] = sqrt(l2_error_per_cell);
        
        l2_error_per_cell=0;
        ++cell_iterator_first_refine;
      }
      
//       cout << "  solution_values_second_refine_at_quads_per_cell_left\n";
//       print_vector(solution_values_second_refine_at_quads_per_cell_left);
//       cout << "  solution_values_second_refine_at_quads_per_cell_right\n";
//       print_vector(solution_values_second_refine_at_quads_per_cell_right);
//       cout << "  solution_values_second_refine_at_quads_per_cell\n";
//       print_vector(solution_values_second_refine_at_quads_per_cell);
//       cout << "  solution_values_first_refine_at_quads_per_cell\n";
//       print_vector(solution_values_first_refine_at_quads_per_cell);
      
    }
    
  }else if(dim==2)
  {
    unsigned int n_q_points_one_block=pow(int((sqrt(n_q_points)+1)/2.0),2);
//     cout << "  nr. of quadrature points in one block: " << n_q_points_one_block << "\n";  
        
    vector<Point<dim> > quad_coords_vector_0_0;                            // split quad_coords_vector into blocks
    vector<Point<dim> > quad_coords_vector_1_0;
    vector<Point<dim> > quad_coords_vector_0_1;
    vector<Point<dim> > quad_coords_vector_1_1;
  
    vector<int> quad_indices_vector_0_0;
    vector<int> quad_indices_vector_1_0;
    vector<int> quad_indices_vector_0_1;
    vector<int> quad_indices_vector_1_1;
  
    vector<int> quad_indices_vector;
  
    for (unsigned int i=0; i<quad_coords_vector.size();++i)
    {
//     cout << "  [" << i << "]: " << quad_coords_vector[i] << " ";
    
      if(quad_coords_vector[i](0)<=0.5 && quad_coords_vector[i](1)<=0.5)
      {
//       cout << "  to 0_0";
        quad_coords_vector_0_0.push_back(quad_coords_vector[i]);
        quad_indices_vector_0_0.push_back(i);
      }
      if (quad_coords_vector[i](0)>=0.5 && quad_coords_vector[i](1)<=0.5)
      {
//       cout << "  to 1_0";
        quad_coords_vector_1_0.push_back(quad_coords_vector[i]);
        quad_indices_vector_1_0.push_back(i);
      }
      if(quad_coords_vector[i](0)<=0.5 && quad_coords_vector[i](1)>=0.5)
      {
//       cout << "  to 0_1";
        quad_coords_vector_0_1.push_back(quad_coords_vector[i]);
        quad_indices_vector_0_1.push_back(i);
      }
      if(quad_coords_vector[i](0)>=0.5 && quad_coords_vector[i](1)>=0.5)
      {
//       cout << "  to 1_1";
        quad_coords_vector_1_1.push_back(quad_coords_vector[i]);
        quad_indices_vector_1_1.push_back(i);
      }
//     cout << "\n";
    }
  
    quad_indices_vector.insert(quad_indices_vector.end(),quad_indices_vector_0_0.begin(),quad_indices_vector_0_0.end());
    quad_indices_vector.insert(quad_indices_vector.end(),quad_indices_vector_1_0.begin(),quad_indices_vector_1_0.end());
    quad_indices_vector.insert(quad_indices_vector.end(),quad_indices_vector_0_1.begin(),quad_indices_vector_0_1.end());
    quad_indices_vector.insert(quad_indices_vector.end(),quad_indices_vector_1_1.begin(),quad_indices_vector_1_1.end());
  
//   cout << "\n";
//   cout << "  quad_indices_vector_0_0\n";
//   print_vector(quad_indices_vector_0_0);
//   cout << "  quad_indices_vector_1_0\n";
//   print_vector(quad_indices_vector_1_0);
//   cout << "  quad_indices_vector_0_1\n";
//   print_vector(quad_indices_vector_0_1);
//   cout << "  quad_indices_vector_1_1\n";
//   print_vector(quad_indices_vector_1_1);
  
//   cout << "  quad_indices_vector\n";
//   print_vector(quad_indices_vector);
//   
//   cout << "\n";
//   cout << "  quad_coords_vector_0_0\n";
//   print_vector(quad_coords_vector_0_0);
//   cout << "  quad_coords_vector_1_0\n";
//   print_vector(quad_coords_vector_1_0);
//   cout << "  quad_coords_vector_0_1\n";
//   print_vector(quad_coords_vector_0_1);
//   cout << "  quad_coords_vector_1_1\n";
//   print_vector(quad_coords_vector_1_1);
  
  
//   obj_string="data_quad_coords_adjusted";
//   save_vector_of_Point_to_txt(obj_string,quad_coords_vector);

    scale_quad_coords_small(quad_coords_vector_0_0);                        // scale quad_coords_vector_i_j
    scale_quad_coords_big(quad_coords_vector_1_0);
    scale_quad_coords_small(quad_coords_vector_0_1);
    scale_quad_coords_big(quad_coords_vector_1_1);
  
//   cout << "  quad_coords_vector_i_j after scaling: \n";
//   cout << "  quad_coords_vector_0_0\n";
//   print_vector(quad_coords_vector_0_0);
//   cout << "  quad_coords_vector_1_0\n";
//   print_vector(quad_coords_vector_1_0);
//   cout << "  quad_coords_vector_0_1\n";
//   print_vector(quad_coords_vector_0_1);
//   cout << "  quad_coords_vector_1_1\n";
//   print_vector(quad_coords_vector_1_1);
  
  
    obj_string="data_quad_coords_0_0";
    save_vector_of_Point_to_txt(obj_string,quad_coords_vector_0_0);
    obj_string="data_quad_coords_1_0";
    save_vector_of_Point_to_txt(obj_string,quad_coords_vector_1_0);
    obj_string="data_quad_coords_0_1";
    save_vector_of_Point_to_txt(obj_string,quad_coords_vector_0_1);
    obj_string="data_quad_coords_1_1";
    save_vector_of_Point_to_txt(obj_string,quad_coords_vector_1_1);
  
    cout << "\n";
  
    Quadrature<dim>  quadrature_formula_high_2_low_0_0(quad_coords_vector_0_0);
    Quadrature<dim>  quadrature_formula_high_2_low_1_0(quad_coords_vector_1_0);
    Quadrature<dim>  quadrature_formula_high_2_low_0_1(quad_coords_vector_0_1);
    Quadrature<dim>  quadrature_formula_high_2_low_1_1(quad_coords_vector_1_1);
  
    FEValues<dim> fe_values_high_2_low_0_0 (fe, quadrature_formula_high_2_low_0_0,
                            update_values   | update_gradients | update_hessians |
                            update_quadrature_points | update_JxW_values);
    FEValues<dim> fe_values_high_2_low_1_0 (fe, quadrature_formula_high_2_low_1_0,
                            update_values   | update_gradients | update_hessians |
                            update_quadrature_points | update_JxW_values);
    FEValues<dim> fe_values_high_2_low_0_1 (fe, quadrature_formula_high_2_low_0_1,
                            update_values   | update_gradients | update_hessians |
                            update_quadrature_points | update_JxW_values);
    FEValues<dim> fe_values_high_2_low_1_1 (fe, quadrature_formula_high_2_low_1_1,
                            update_values   | update_gradients | update_hessians |
                            update_quadrature_points | update_JxW_values);
  
  
    vector<double > solution_second_refine_quad_values_0_0(n_q_points_one_block);
    vector<double > solution_second_refine_quad_values_1_0(n_q_points_one_block);
    vector<double > solution_second_refine_quad_values_0_1(n_q_points_one_block);
    vector<double > solution_second_refine_quad_values_1_1(n_q_points_one_block);
    
  
    typename DoFHandler<dim>::active_cell_iterator
    cell = dof_handler.begin_active(),
    endc = dof_handler.end();   
  
    id_cell=0;
    for (; cell!=endc; ++cell)
    {
//     cout  << "  cell: " << id_cell++ << "\n";
      if (cell->active_cell_index()%4==0)
      {
//       cout << "  starting one bunch\n";
//       for (unsigned int vertex=0; vertex < GeometryInfo<dim>::vertices_per_cell; ++vertex)
//       {
//         cout << "      at vertex " << cell->vertex_index(vertex) << ", coords: " << cell->vertex(vertex) << "\n";
//       }

        fe_values_high_2_low_0_0.reinit (cell);
        fe_values_high_2_low_0_0.get_function_values (solution, solution_second_refine_quad_values_0_0);
      
        for (unsigned int i=0; i<n_q_points_one_block; ++i)
        {
          solution_values_second_refine_at_quads_per_cell[quad_indices_vector[i]]=solution_second_refine_quad_values_0_0[i];
        }
      
      }else if (cell->active_cell_index()%4==1)
      {
        fe_values_high_2_low_1_0.reinit (cell);
        fe_values_high_2_low_1_0.get_function_values (solution, solution_second_refine_quad_values_1_0);
      
        for (unsigned int i=0; i<n_q_points_one_block; ++i)
        {
          solution_values_second_refine_at_quads_per_cell[quad_indices_vector[n_q_points_one_block*1+i]]=solution_second_refine_quad_values_1_0[i];
        }
      
      }else if (cell->active_cell_index()%4==2)
      {
        fe_values_high_2_low_0_1.reinit (cell);
        fe_values_high_2_low_0_1.get_function_values (solution, solution_second_refine_quad_values_0_1);
      
//       print_vector(solution_second_refine_quad_values_0_1);   
      
        for (unsigned int i=0; i<n_q_points_one_block; ++i)
        {
          solution_values_second_refine_at_quads_per_cell[quad_indices_vector[n_q_points_one_block*2+i]]=solution_second_refine_quad_values_0_1[i];
        }
      
      }else if (cell->active_cell_index()%4==3)
      {
        fe_values_high_2_low_1_1.reinit (cell);
        fe_values_high_2_low_1_1.get_function_values (solution, solution_second_refine_quad_values_1_1);
      
//       print_vector(solution_second_refine_quad_values_1_1);
      
        for (unsigned int i=0; i<n_q_points_one_block; ++i)
        {
          solution_values_second_refine_at_quads_per_cell[quad_indices_vector[n_q_points_one_block*3+i]]=solution_second_refine_quad_values_1_1[i];
        }      
      
//       cout << "\n";
        cell_index_first_refine = cell_iterator_first_refine->active_cell_index();
//       cout << "  cell of first refinement: " << cell_index_first_refine << endl;                   // evaluating solution values of the first refinement
      
//       cout << "  solution_values_second_refine_at_quads_per_cell: \n";
//       print_vector(solution_values_second_refine_at_quads_per_cell);
      
        fe_values.reinit (cell_iterator_first_refine);
        fe_values.get_function_values (solution_first_refine, solution_values_first_refine_at_quads_per_cell);
      
//       cout << "  solution_values_first_refine_at_quads_per_cell: \n";
//       print_vector(solution_values_first_refine_at_quads_per_cell);
      
      
//       for (unsigned int q_index=0; q_index<n_q_points; ++q_index)
//       {
//         solution_diff_at_quads_per_cell[q_index]=solution_values_second_refine_at_quads_per_cell[q_index]-solution_values_first_refine_at_quads_per_cell[q_index];
//       }
//       
//       cout << "  solution_diff_at_quads_per_cell: \n";
//       print_vector(solution_diff_at_quads_per_cell);
        
        for (unsigned int q_index=0; q_index<n_q_points; ++q_index)
        {
          l2_error_per_cell += pow(solution_values_first_refine_at_quads_per_cell[q_index] - solution_values_second_refine_at_quads_per_cell[q_index],2 ) * fe_values.JxW (q_index) ;
        }   
        cellwise_error[cell_index_first_refine] = sqrt(l2_error_per_cell);
          
        ++cell_iterator_first_refine;          
      }
    }
  }
  
  cout << "\n";
//   cout << "  cellwise_error: ";
//   cellwise_error.print(cout,3);
  
  L2_error_custom = cellwise_error.l2_norm();
  
#endif
}


template <int dim>
void Step4_Real<dim>::print_integrals_errors_and_CPU ()
{
    
  cout << "Printing integrals, errors and CPU time" << endl;
    
  if(is_integral_of_special_interest_computed==1)
  {
    cout << "  u_L2_inte_numerical = " << u_L2_inte_numerical << endl;
    cout << "  u_mean_inte_numerical = " << u_mean_inte_numerical << ", u_mean_inte_analytical = " << u_mean_inte_analytical << endl;
    cout << "  f_L2_inte_numerical = " << f_L2_inte_numerical << ", f_L2_inte_analytical = " << f_L2_inte_analytical << endl;
    cout << endl;
  }
  
  cout << "  ||Eh||_L2 = " << L2_error << ", r_N = " << r_N << ", u_L2_inte_analytical = " << u_L2_inte_analytical << "\n";
  cout << "  ||Eh||_H1_seminorm = " << H1_semi_error << ", r_Np = " << r_Np << ", H1_N = " << H1_N << "\n";    
  cout << "  ||Eh||_H2_seminorm = " << H2_semi_error << ", r_Npp = " << r_Npp << ", H2_N = " << H2_N << "\n";
  
  if (is_custom_method_used_for_error==1)
  {
    cout << "  L2_error_custom: " << L2_error_custom << endl;                  // we allow slight difference from that using the built-in function since we use finer solution as exact
  }
  
  cout << "  total_CPU_time: " << total_CPU_time << endl;
  cout << endl;
}


template <int dim>
void Step4_Real<dim>::output_results () const
{ 
  ComputeSurface_Real<dim> surface;
  ComputeVelocity1_Real<dim> velocity;
  Compute2ndderivative1_Real<dim> secondderivative;

  DataOut<dim> data_out;

  data_out.attach_dof_handler (dof_handler);
  data_out.add_data_vector (solution, "");
}


template <int dim>
void Step4_Real<dim>::refine_grid ()                 
{
  Vector<float> estimated_error_per_cell (triangulation.n_active_cells());
  
  KellyErrorEstimator<dim>::estimate (dof_handler,
                                      QGauss<dim-1>(3),
                                      typename FunctionMap<dim>::type(),
                                      solution,
                                      estimated_error_per_cell);

  GridRefinement::refine_and_coarsen_fixed_number (triangulation,
                                                   estimated_error_per_cell,
                                                   0.4, 0.00);
  triangulation.execute_coarsening_and_refinement ();
}


template <int dim>
void Step4_Real<dim>::run ()
{
  make_grid();
  for (unsigned int cycle=0; cycle<1;cycle++)     // cycle used for adaptive mesh refinement
  {
    cycle_global = cycle;
    
    cout << "\n";
//     print_fe_info(dim, fe);
//     print_quadrature_info(quadrature_formula);
    
    if(is_basis_extracted==1)
    {
      extract_basis_function(fe);  
    }
    
    setup_system ();
    assemble_system ();
    solve ();
  
    if (is_integral_of_special_interest_computed==1)
    {
      compute_integrals ();
    }
    compute_errors_built_in ();
    if (is_custom_method_used_for_error==1)
    {
        compute_errors_custom ();
    }
    
    if(is_results_stored==1)
    {
      output_results ();  
    }

    total_CPU_time = computing_timer.return_total_cpu_time();        // validated by the original function computing_timer.print_summary();
                                                                     // "+=" might not work
    
    computing_timer.print_summary();
    
#if 1
    print_integrals_errors_and_CPU();
    store_error_cpu_time_to_file();
    
    if (cycle>0)
    {
      refine_grid();  
    }
#endif

  }
}



#endif

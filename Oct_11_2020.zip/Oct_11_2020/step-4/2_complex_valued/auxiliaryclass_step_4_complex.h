
#ifndef AUXILIARYCLASS_STEP_4_COMPLEX_H
#define AUXILIARYCLASS_STEP_4_COMPLEX_H

template <int dim>
class ExactSolution_Step_4_Complex_Amp : public Function<dim>,                                                                 //exact solution for the amplitude
public Common_Var_Complex<dim>
{
public:
  using Common_Var_Complex<dim>::Common_Var_Complex;
  ExactSolution_Step_4_Complex_Amp (const unsigned int id_case);
  virtual double value (const Point<dim>   &p,
                        const unsigned int  component = 0) const;
protected:
  const unsigned int id_case;
};

template <int dim>
class ExactSolution_Step_4_Complex_Real : public Function<dim>,                                                            //exact solution for the real part
public Common_Var_Complex<dim>
{
public:
  using Common_Var_Complex<dim>::Common_Var_Complex;
  ExactSolution_Step_4_Complex_Real (const unsigned int id_case);
  virtual double value (const Point<dim>   &p,
                        const unsigned int  component = 0) const;
  virtual Tensor<1,dim> gradient (const Point<dim>   &p,
                                  const unsigned int  component = 0) const;
  virtual SymmetricTensor<2,dim> hessian (const Point<dim>   &p,
                                  const unsigned int  component = 0) const;     
protected:
  const unsigned int id_case;
};

template <int dim>
class ExactSolution_Step_4_Complex_Imag : public Function<dim>,                                                           //exact solution for the imaginary part
public Common_Var_Complex<dim>
{
public:
  ExactSolution_Step_4_Complex_Imag (const unsigned int id_case);
  virtual double value (const Point<dim>   &p,
                        const unsigned int  component = 0) const;
  virtual Tensor<1,dim> gradient (const Point<dim>   &p,
                                  const unsigned int  component = 0) const;
  virtual SymmetricTensor<2,dim> hessian (const Point<dim>   &p,
                                  const unsigned int  component = 0) const;           
protected:
  const unsigned int id_case;           
};


template <int dim>
ExactSolution_Step_4_Complex_Amp<dim>::ExactSolution_Step_4_Complex_Amp(const unsigned int id_case): Function<dim>(dim+1),Common_Var_Complex<dim>(id_case),
id_case(id_case)
{}

template <int dim>
ExactSolution_Step_4_Complex_Real<dim>::ExactSolution_Step_4_Complex_Real(const unsigned int id_case): Function<dim>(dim+1),Common_Var_Complex<dim>(id_case),
id_case(id_case)
{}

template <int dim>
ExactSolution_Step_4_Complex_Imag<dim>::ExactSolution_Step_4_Complex_Imag(const unsigned int id_case): Function<dim>(dim+1),Common_Var_Complex<dim>(id_case),
id_case(id_case)
{}


template <int dim>
double ExactSolution_Step_4_Complex_Amp<dim> :: value (const Point<dim>   &p,
                                                   const unsigned int ) const
{
  double return_value;
  switch(id_case)
  {
    case 1:
      cout << "  exact solution does not exist\n";
      throw exception();
    case 2:
      return_value = std::abs(this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]));            // absolute value of the exact solution (amplitude)  
      break;
    default:
      cout << "  case does not exist\n";
      throw exception();      
  }
  return return_value;
}

template <int dim>
double ExactSolution_Step_4_Complex_Real<dim> :: value (const Point<dim>   &p,
                                                        const unsigned int ) const
{
  double return_value;
  switch(id_case)
  {
    case 1:
      cout << "  exact solution does not exist\n";
      throw exception();
    case 2:
      if (dim==1)
      {
        return_value = (this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0])).real();       
      }else if(dim==2)
      {        
        return_value = ((this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]))*cos(this->coeff_y*(p[1]-this->centre_y))).real();            // real p
      }
      break;
    default:
      cout << "  case does not exist\n";
      throw exception();      
  }
  return return_value;
}

template <int dim>
Tensor<1,dim> ExactSolution_Step_4_Complex_Real<dim>::gradient (const Point<dim>   &p,
                                                                const unsigned int) const
{
  Tensor<1,dim> return_value;
  switch(id_case)
  {
    case 1:
      cout << "  exact solution does not exist\n";
      throw exception();
    case 2:
      if (dim==1)
      {
        return_value[0] = (this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0])).real(); 
      }else if(dim==2)
      {         
        return_value[0] = ((this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0]))*cos(this->coeff_y*(p[1]-this->centre_y))).real();   // real p_x
        return_value[1] = ((this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]))*(-this->coeff_y*sin(this->coeff_y*(p[1]-this->centre_y)))).real();    // real p_y
      }
      break;
    default:
      cout << "  case does not exist\n";
      throw exception();      
  }
  return return_value;
}

template <int dim>
SymmetricTensor<2,dim> ExactSolution_Step_4_Complex_Real<dim>::hessian (const Point<dim>   &p,
                                                                        const unsigned int) const
{
  SymmetricTensor<2,dim> return_value;
  switch(id_case)
  {
    case 1:
      cout << "  exact solution does not exist\n";
      throw exception();
    case 2:
      if (dim==1)
      {
        return_value[0][0] = (this->A*pow(this->r1,2.0)*std::exp(this->r1*p[0])+this->B*pow(this->r2,2.0)*std::exp(this->r2*p[0])).real();   
      }else if(dim==2)
      {        
        return_value[0][0] = ((this->A*pow(this->r1,2.0)*std::exp(this->r1*p[0])+this->B*pow(this->r2,2.0)*std::exp(this->r2*p[0]))*cos(this->coeff_y*(p[1]-this->centre_y))).real(); // real p_xx
        return_value[0][1] = ((this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0]))*(-this->coeff_y*sin(this->coeff_y*(p[1]-this->centre_y)))).real();  // real p_xy
        return_value[1][0] = ((this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0]))*(-this->coeff_y*sin(this->coeff_y*(p[1]-this->centre_y)))).real();  // real p_yx
        return_value[1][1] = ((this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]))*(-pow(this->coeff_y,2.0)*cos(this->coeff_y*(p[1]-this->centre_y)))).real();  // real p_yy
      }
      break;
    default:
      cout << "  case does not exist\n";
      throw exception();      
  }
  return return_value;
}

template <int dim>
double ExactSolution_Step_4_Complex_Imag<dim> :: value (const Point<dim>   &p,
                                                        const unsigned int ) const
{
  double return_value;
  switch(id_case)
  {
    case 1:
      cout << "  exact solution does not exist\n";
      throw exception();
    case 2:
      if (dim==1)
      {
        return_value = (this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0])).imag();       
      }else if(dim==2)
      {        
        return_value = ((this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]))*cos(this->coeff_y*(p[1]-this->centre_y))).imag();            // imag p
      }
      break;
    default:
      cout << "  case does not exist\n";
      throw exception();      
  }
  return return_value;
}

template <int dim>
Tensor<1,dim> ExactSolution_Step_4_Complex_Imag<dim>::gradient (const Point<dim>   &p,
                                       const unsigned int) const
{
  Tensor<1,dim> return_value;
  switch(id_case)
  {
    case 1:
      cout << "  exact solution does not exist\n";
      throw exception();
    case 2:
      if (dim==1)
      {
        return_value[0] = (this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0])).imag(); 
      }else if(dim==2)
      {         
        return_value[0] = ((this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0]))*cos(this->coeff_y*(p[1]-this->centre_y))).imag();   // imag p_x
        return_value[1] = ((this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]))*(-this->coeff_y*sin(this->coeff_y*(p[1]-this->centre_y)))).imag();    // imag p_y
      }
      break;
    default:
      cout << "  case does not exist\n";
      throw exception();      
  }
  return return_value;
}

template <int dim>
SymmetricTensor<2,dim> ExactSolution_Step_4_Complex_Imag<dim>::hessian (const Point<dim>   &p,
                                       const unsigned int) const
{
  SymmetricTensor<2,dim> return_value;
  switch(id_case)
  {
    case 1:
      cout << "  exact solution does not exist\n";
      throw exception();
    case 2:
      if (dim==1)
      {
        return_value[0][0] = (this->A*pow(this->r1,2.0)*std::exp(this->r1*p[0])+this->B*pow(this->r2,2.0)*std::exp(this->r2*p[0])).imag();   
      }else if(dim==2)
      {        
        return_value[0][0] = ((this->A*pow(this->r1,2.0)*std::exp(this->r1*p[0])+this->B*pow(this->r2,2.0)*std::exp(this->r2*p[0]))*cos(this->coeff_y*(p[1]-this->centre_y))).imag(); // imag p_xx
        return_value[0][1] = ((this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0]))*(-this->coeff_y*sin(this->coeff_y*(p[1]-this->centre_y)))).imag();  // imag p_xy
        return_value[1][0] = ((this->A*this->r1*std::exp(this->r1*p[0])+this->B*this->r2*std::exp(this->r2*p[0]))*(-this->coeff_y*sin(this->coeff_y*(p[1]-this->centre_y)))).imag();  // imag p_yx
        return_value[1][1] = ((this->A*std::exp(this->r1*p[0])+this->B*std::exp(this->r2*p[0]))*(-pow(this->coeff_y,2.0)*cos(this->coeff_y*(p[1]-this->centre_y)))).imag();  // imag p_yy
      }
      break;
    default:
      cout << "  case does not exist\n";
      throw exception();      
  }
  return return_value;
}

#endif

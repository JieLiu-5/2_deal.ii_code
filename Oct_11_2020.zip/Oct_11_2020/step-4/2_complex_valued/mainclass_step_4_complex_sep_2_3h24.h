
#ifndef MAINCLASS_STEP_4_COMPLEX_H
#define MAINCLASS_STEP_4_COMPLEX_H

#include <2_complex_valued/auxiliaryclass_step_4_complex.h>


template <int dim>
class Step4_Complex
{
public:
  Step4_Complex (const unsigned int id_case, const double length, const unsigned int degree, const int grid_parm);
  void run ();
    
  double solu_amp_diff_inte;
  double solu_real_L2, solu_imag_L2, solu_L2;

  double solu_real_diff_inte;
  double solu_imag_diff_inte;

  double solution_real_L2_error, solution_real_H1_semi_error, solution_real_H2_semi_error;
  double solution_imag_L2_error, solution_imag_H1_semi_error, solution_imag_H2_semi_error;
  double solution_L2_error, solution_H1_semi_error, solution_H2_semi_error;
  
  double H1_N;
  double H1_error;
  double H1_N_real;
  double H1_error_real;
  double H1_N_imag;
  double H1_error_imag;
  double r_Np;
  
  double H2_N;
  double H2_error;
  double H2_N_real;
  double H2_error_real;
  double H2_N_imag;
  double H2_error_imag;
  double r_Npp;

private:
    
  void make_grid ();
  void setup_system();
  void assemble_system ();
  void solve ();
  void compute_l2_norm ();
  void compute_errors_quad ();
  void process_errors();
  void print_errors_and_CPU ();
  void output_results ();

  const unsigned int   id_case; 
  const double length;
  const unsigned int   degree; 
  const unsigned int   refine;
  
  const int n_dofs_custom;
  const int n_vertices_custom;
  
  
  QGauss<dim> quadrature_formula = QGauss<dim>(degree+1);
  const unsigned int n_q_points = quadrature_formula.size();
  
  
  unsigned int is_global_mesh=1;           // '1' for the global mesh; '0' for the 'vertex' mesh, checked on Sep. 26, 2019
  
  Triangulation<dim>   triangulation;
  Triangulation<dim>   triangulation_first_refine;
  
  FESystem<dim>        fe;
  FE_Q<dim>            fe_amp;
  
  DoFHandler<dim>      dof_handler;
  DoFHandler<dim>      dof_handler_amp;
  DoFHandler<dim>      dof_handler_amp_first_refine;


  SparsityPattern      sparsity_pattern;
  SparseMatrix<double> system_matrix;

  Vector<double>       system_rhs;
  
  
  unsigned int is_matrices_before_BC_printed = 0;
  unsigned int is_matrices_after_BC_printed = 0;
  
  string obj_string;
  unsigned int is_matrix_after_BC_stored = 0;
  unsigned int is_rhs_after_BC_stored = 0;
  
  unsigned int is_UMFPACK = 1;  
  
  Vector<double>       solution;
  Vector<double>       solution_first_refine;
  Vector<double>       solution_second_refine;

  Vector<double>       solution_amp;
  Vector<double>       solution_amp_0;
  
  Vector<double>       solution_real;
  Vector<double>       solution_real_second_refine;
  Vector<double>       solution_real_sequence; 
  
  Vector<double>       solution_imag;
  Vector<double>       solution_imag_second_refine;
  Vector<double>       solution_imag_sequence;
  
  unsigned int is_solution_printed = 0;
  unsigned int is_solution_sequence_handled = 0;
  
  unsigned int is_results_stored=1;
  
  TimerOutput                               computing_timer;
  void printToFile();
  double total_CPU_time;
};


std::ofstream myfile;
template <int dim>
void Step4_Complex<dim>::printToFile()
{
  if(dim==1)
  {
    obj_string="oned";  
  }else if(dim==2)
  {
    obj_string="twod";
  }
  myfile.open ("data_error_helm_xi_"+obj_string+"_mm.txt", ofstream::app);
  myfile << refine <<" ";
  myfile << triangulation_first_refine.n_vertices() <<" ";    
  myfile << dof_handler_amp_first_refine.n_dofs() * 2 << " ";    
  myfile << solution_L2_error << " ";
  myfile << solution_H1_semi_error << " ";
  myfile << solution_H2_semi_error << " ";
  myfile << total_CPU_time << " ";
  myfile << solu_L2 <<"\n";
}


template <int dim>
Step4_Complex<dim>::Step4_Complex (const unsigned int id_case, const double length, const unsigned int degree, const int grid_parm)
  :
  id_case(id_case),
  length(length),
  degree(degree),
  refine(grid_parm),
  n_dofs_custom(grid_parm),
//   n_vertices_custom(grid_parm),
  n_vertices_custom ((n_dofs_custom/2-1)/degree+1), 
  
  fe (FE_Q<dim>(degree),2),
  fe_amp (degree),
  
  dof_handler (triangulation),
  dof_handler_amp (triangulation),
  dof_handler_amp_first_refine (triangulation_first_refine),  
  computing_timer  (cout, TimerOutput::summary, TimerOutput::cpu_times)

{
  cout << "================== \n"
       << "  The standard FEM for complex-valued problems\n"
       << "  case: " << id_case << "\n"
       << "  dimension: " << dim << "\n"
       << "  n_q_points: " << n_q_points 
       << endl;    
  cout << "================== " << endl;    
}



template <int dim>
void Step4_Complex<dim>::make_grid ()
{
  TimerOutput::Scope t(computing_timer, "make grid");
    
  if(is_global_mesh==1)
  {
    GridGenerator::hyper_cube (triangulation, 0, length);
  }else if(is_global_mesh == 0)
  {
    //   GridGenerator::my_hyper_cube (triangulation, 0, 1);
    cout << "    n_dofs_custom: " << n_dofs_custom << endl;
    cout << "    n_vertices_custom: " << n_vertices_custom << endl;
    std::vector<Point<dim>> vertices(n_vertices_custom);
    const double delta_vertex = 1.0/(n_vertices_custom-1);
    
    for (int i = 0; i < n_vertices_custom; ++i)
    {
        vertices[i](0) = i * delta_vertex;
    }

    std::vector<std::array<int,GeometryInfo<1>::vertices_per_cell>> cell_vertices;
    std::array<int,GeometryInfo<1>::vertices_per_cell> array_update;
    
    for (int i = 0; i<n_vertices_custom-1; ++i)
    {
        array_update = {i,i+1};
        cell_vertices.push_back(array_update);
    }
    
    std::vector<CellData<dim>> cells(cell_vertices.size(), CellData<dim>());
    for (unsigned int i=0; i<cell_vertices.size(); ++i)
    {
        for (unsigned int j=0; j<GeometryInfo<1>::vertices_per_cell; ++j)
        {
            cells[i].vertices[j] = cell_vertices[i][j];
        }
    }
    
    triangulation.create_triangulation (vertices, cells, SubCellData());  
  }
  
  if (dim==1)
  {  
//   triangulation.begin_active()->face(1)->set_boundary_id(0);            // set both boundary conditions as Dirichlet type
//   triangulation.last_active()->face(1)->set_boundary_id(0);      
  }else if(dim==2)
  {
    adjust_boundary_id_2d(triangulation);
  }
  
  

  print_boundary_info(triangulation);

  triangulation.refine_global (refine);  
  
  triangulation_first_refine.copy_triangulation(triangulation);
  
  dof_handler_amp_first_refine.distribute_dofs (fe_amp);
  
//   cout << "  coords of dofs of dof_handler\n";
//   print_coordinates_of_dofs(degree, dof_handler);
/*  cout << "  coords of dofs of dof_handler_amp_first_refine: ";
  print_coordinates_of_dofs(degree, dof_handler_amp_first_refine); */ 

  print_dofs_info(dof_handler_amp_first_refine);
}


template <int dim>
void Step4_Complex<dim>::setup_system ()
{
//   TimerOutput::Scope t(computing_timer, "setup_system");
  dof_handler.distribute_dofs (fe);
  dof_handler_amp.distribute_dofs (fe_amp);

  DynamicSparsityPattern dsp(dof_handler.n_dofs());
  DoFTools::make_sparsity_pattern (dof_handler, dsp);
  sparsity_pattern.copy_from(dsp);

  system_matrix.reinit (sparsity_pattern);
  solution.reinit (dof_handler.n_dofs());
  
  system_rhs.reinit (dof_handler.n_dofs());

  solution_amp.reinit (dof_handler_amp.n_dofs());
  solution_amp_0.reinit (dof_handler_amp.n_dofs());
  
  solution_real.reinit (dof_handler_amp.n_dofs());
  solution_imag.reinit (dof_handler_amp.n_dofs());
  solution_real_sequence.reinit (dof_handler_amp.n_dofs());
  solution_imag_sequence.reinit (dof_handler_amp.n_dofs());
}




template <int dim>
void Step4_Complex<dim>::assemble_system ()
{
  TimerOutput::Scope t(computing_timer, "assemble system");
  cout << "Assembling\n";
  
  const RightHandSide_Complex<dim> right_hand_side(id_case);
  
  FEValues<dim> fe_values (fe, quadrature_formula,
                           update_values   | update_gradients | update_hessians |
                           update_quadrature_points | update_JxW_values);


  const unsigned int   dofs_per_cell = fe.dofs_per_cell;
  
  Coeff_Diff_Complex<dim> coeff_diff_complex(id_case, 1.0);
  Coeff_Helm_Complex<dim> coeff_helm_complex(id_case, 1.0);
  
  vector<Vector<double>> coeff_diff_values_complex(n_q_points,Vector<double>(2));
  vector<Vector<double>> coeff_helm_values_complex(n_q_points,Vector<double>(2));
  
  FullMatrix<double>   cell_matrix (dofs_per_cell, dofs_per_cell);
  Vector<double>       cell_rhs (dofs_per_cell);

  std::vector<types::global_dof_index> local_dof_indices (dofs_per_cell);

  typename DoFHandler<dim>::active_cell_iterator
  cell = dof_handler.begin_active(),
  endc = dof_handler.end();

  for (; cell!=endc; ++cell)
  {
    fe_values.reinit (cell);
    cell_matrix = 0;
    cell_rhs = 0;
    
    coeff_diff_complex.value(fe_values.get_quadrature_points(), coeff_diff_values_complex);
    coeff_helm_complex.value(fe_values.get_quadrature_points(), coeff_helm_values_complex);
    
//     cout << "active_cell_index(): " << cell->active_cell_index() << ", vertex(0): (" << cell->vertex(0) << "), at boundary: " << cell->at_boundary() << endl;

    for (unsigned int q_index=0; q_index</*1*/ n_q_points; ++q_index)             //diagonal part
    {
      for (unsigned int i=0; i<dofs_per_cell; ++i)
      {
//         cout << "  fe.system_to_component_index(i).first: " << fe.system_to_component_index(i).first << endl;
//         cout << "  fe_values.shape_grad (i, 0): " << fe_values.shape_grad (i, 0) << endl;
        
        for (unsigned int j=0; j<dofs_per_cell; ++j)
        {
          if (fe.system_to_component_index(i).first == fe.system_to_component_index(j).first)               // we use this to justify if two basis functions belong to the same part
          {
            cell_matrix(i,j) += (coeff_diff_values_complex[q_index][0] * fe_values.shape_grad (i, q_index) * fe_values.shape_grad (j, q_index)) * fe_values.JxW (q_index);
            cell_matrix(i,j) += (coeff_helm_values_complex[q_index][0] * fe_values.shape_value (i, q_index) * fe_values.shape_value (j, q_index)) *fe_values.JxW(q_index);
          }else                                         
          {
            cell_matrix(i,j) += (coeff_diff_values_complex[q_index][1] * fe_values.shape_grad (i, q_index) * fe_values.shape_grad (j, q_index)) * fe_values.JxW (q_index);
            cell_matrix(i,j) += (coeff_helm_values_complex[q_index][1] * fe_values.shape_value (i, q_index) * fe_values.shape_value (j, q_index)) *fe_values.JxW(q_index);
          }
        }
        if (fe.system_to_component_index(i).first == 0)		// working on the real parts
        {
          cell_rhs(i) += (fe_values.shape_value (i, q_index) *
                          right_hand_side.value (fe_values.quadrature_point (q_index)) *
                          fe_values.JxW (q_index));
        }                 
      } 
    }
      
    cell->get_dof_indices (local_dof_indices);
    
//     cout << "  local_dof_indices: \n";
//     print_vector(local_dof_indices);

    for (unsigned int i=0; i<dofs_per_cell; ++i)
    {
      for (unsigned int j=0; j<dofs_per_cell; ++j)
      {
        system_matrix.add (local_dof_indices[i],
                           local_dof_indices[j],
                           cell_matrix(i,j));
      }
      system_rhs(local_dof_indices[i]) += cell_rhs(i);
    }
  }

  if(is_matrices_before_BC_printed==1)
  {
    cout << "  system_matrix before applying BCs is " << endl;
    system_matrix.print_formatted(cout);
    cout << '\n';

    cout << "  system_rhs before applying BCs is " << endl;
    cout << system_rhs << endl;
  }
  
  cout << "  dealing with the Dirichlet boundary condition\n";
  
  std::map<types::global_dof_index,double> boundary_values;
  
  VectorTools::interpolate_boundary_values (dof_handler,
                                            0,
                                            DirichletBoundaryValues_Step_4_Complex<dim>(id_case),
                                            boundary_values);
  
  cout << "  the resulting boundary_values: \n";
  print_map(boundary_values);

  MatrixTools::apply_boundary_values (boundary_values,
                                      system_matrix,
                                      solution,
                                      system_rhs);
  
  if(is_matrices_after_BC_printed==1)
  {
    cout << "  system_matrix after applying BCs is " << endl;
    system_matrix.print_formatted(cout);
    cout << '\n';
    cout << "  system_rhs after applying BCs is " << endl;
    cout << system_rhs << endl;      
  }
  
  if(is_matrix_after_BC_stored==1)
  {
    obj_string="system_matrix_helm_xi_"+to_string(dim)+"d_deg_"+to_string(degree)+"_ref_"+to_string(refine);
    save_system_matrix_to_txt(obj_string,system_matrix);
  }
  if(is_rhs_after_BC_stored==1)
  {
    obj_string="system_rhs_oned_helm_xi_"+to_string(dim)+"d_deg_"+to_string(degree)+"_ref_"+to_string(refine);
    save_system_matrix_to_txt(obj_string,system_matrix);
  }
}


template <int dim>
void Step4_Complex<dim>::solve ()
{
  TimerOutput::Scope t(computing_timer, "solve");
  cout << "Solving " << endl;

  if (is_UMFPACK == 1)
  {
//         cout << "    UMFPACK solver" << endl;
    SparseDirectUMFPACK  A_direct;                      
    A_direct.initialize(system_matrix);
    A_direct.vmult (solution, system_rhs);
        
  }else if (is_UMFPACK == 0)
  {
//         cout << "    CG solver" << endl;
    SolverControl           solver_control (1e+8, 1e-16);
    SolverCG<>              solver (solver_control);
        
    solver.solve (system_matrix, solution, system_rhs,
                  PreconditionIdentity());
      
    cout << "   " << solver_control.last_value()
         << "  is the convergence value of last iteration step."
         << endl;
  }

  solution_real[0]=solution[0];
  solution_imag[0]=solution[1];

  for (unsigned int i = 0; i < triangulation.n_active_cells(); i++)
  {
    solution_real[i*degree+1] = solution[degree*2*i+2];
    solution_imag[i*degree+1] = solution[degree*2*i+3];
                
    for (unsigned int j = 2; j < degree+1; j++)
    {
      solution_real[i*degree+j] = solution[degree*2*i+2+j];
      solution_imag[i*degree+j] = solution[degree*2*i+2+j+degree-1];
    }
  }
  
  for (unsigned int i = 0; i < dof_handler.n_dofs()/2.0; i++)
  {
    solution_amp[i] = std::sqrt(solution_real[i]*solution_real[i] + solution_imag[i]*solution_imag[i]);
  }
  
  if(is_solution_sequence_handled==1)
  {
    solution_real_sequence[0]=solution_real[0];
    solution_imag_sequence[0]=solution_imag[0];
    
    for (unsigned int i = 0; i < triangulation.n_active_cells(); i++)
    {
        solution_real_sequence[i*degree+degree] = solution_real[i*degree+1];
        solution_imag_sequence[i*degree+degree] = solution_imag[i*degree+1];
            
        for (unsigned int j = 0; j < degree-1; j++)
        {
        solution_real_sequence[i*degree+j+1] = solution_real[degree*i+j+2];
        solution_imag_sequence[i*degree+j+1] = solution_imag[degree*i+j+2];
        }
    }
      
    cout << "solution_real_sequence is: " << endl << solution_real_sequence << endl;
    cout << "solution_imag_sequence is: " << endl << solution_imag_sequence << endl;  
  }
}


template <int dim>
void Step4_Complex<dim>::output_results ()
{
  TimerOutput::Scope t(computing_timer, "output results");
  cout << "Storing results\n";
  
  //ComputeVelocity1<dim> velocity1;
  //Compute2ndderivative1<dim> secondderivative1;
  DataOut<dim> data_out;

  data_out.attach_dof_handler (dof_handler);
  data_out.add_data_vector (solution, "solution");

  data_out.build_patches ();

  std::ofstream output (dim == 1 ?
                        "solution-complex-sm-1d.vtk" :
                        "solution-complex-sm-2d.vtk");
  data_out.write_vtk (output);
}
  
template <int dim>
void Step4_Complex<dim>::compute_l2_norm ()
{
  TimerOutput::Scope t(computing_timer, "compute L2 norm");
  
  Vector<double> difference_per_cell (triangulation.n_active_cells());
  
//    VectorTools::integrate_difference (dof_handler_amp,                  //which computes 0- for each cell, and saves them to difference_per_cell
//                                      solution_amp,
//                                      ZeroFunction<dim>(),
//                                      difference_per_cell,
//                                      QGauss<dim>(3),
//                                      VectorTools::mean);                // 'mean' integrates function difference per cell, which is 0-solution_amp; later when adding the differences together, we use '-' to reverse to the correct difference, i.e. 'solution_amp - 0'
//     solu_amp_diff_inte = -difference_per_cell.mean_value() * triangulation.n_active_cells();      // we don't need the L2 norm here; we just need to add the error of each cell together.


//     cout << " solu_amp_diff_inte = " << solu_amp_diff_inte << endl;    
/*    solu_amp_diff_inte = VectorTools::compute_global_error(triangulation,
                                                           difference_per_cell,
                                                           VectorTools::L2_norm);
    cout << " solu_amp_diff_inte = " << solu_amp_diff_inte << endl; */   


//  VectorTools::integrate_difference (dof_handler_amp,                                       //real part
//                                     solution_real,
//                                     ZeroFunction<dim>(),
//                                     difference_per_cell,
//                                     QGauss<dim>(degree+2),
//                                     VectorTools::mean); 
//  solu_real_diff_inte = -difference_per_cell.mean_value() * triangulation.n_active_cells();   
//  
   VectorTools::integrate_difference (dof_handler_amp,              // compute the L2 norm of the real part
                                    solution_real,
                                    ZeroFunction<dim>(),
                                    difference_per_cell,
                                    QGauss<dim>(3),
                                    VectorTools::L2_norm);
   solu_real_L2 = difference_per_cell.l2_norm();
 
//    VectorTools::integrate_difference (dof_handler_amp,                                       //imag part
//                    solution_imag,
//                    ZeroFunction<dim>(),
//                    difference_per_cell,
//                    QGauss<dim>(degree+2),
//                    VectorTools::mean);
//    solu_imag_diff_inte = -difference_per_cell.mean_value() * triangulation.n_active_cells();
//  
   VectorTools::integrate_difference (dof_handler_amp,              // compute the L2 norm of the imag part
                                    solution_imag,
                                    ZeroFunction<dim>(),
                                    difference_per_cell,
                                    QGauss<dim>(3),
                                    VectorTools::L2_norm);
   solu_imag_L2 = difference_per_cell.l2_norm(); 
 
//  solu_rel_err = solu_real_L2/solu_amp_diff_inte;
   
    solu_L2 = pow(pow(solu_real_L2,2)+pow(solu_imag_L2,2),0.5);
 
//  cout << " solu_amp_diff_inte = " << solu_amp_diff_inte << endl;
//  cout << " solu_real_diff_inte = " << solu_real_diff_inte << endl;
//  cout << " solu_imag_diff_inte = " << solu_imag_diff_inte << ", solu_imag_L2 = " << solu_imag_L2 << endl;

//  cout << ", ||Eh||_L2 = " << solu_real_L2;
//  cout << ", solu_rel_err = " << solu_rel_err << endl;

}


template <int dim>
void Step4_Complex<dim>::compute_errors_quad ()
{
  TimerOutput::Scope t(computing_timer, "compute errors quad");
  
  double error_quad_real = 0, error_quad_imag = 0;  
    
  std::vector<double> coords_all_quads_first_refine;

  FEValues<dim> fe_values (fe_amp, quadrature_formula,
                          update_values   | update_gradients | update_hessians |
                          update_quadrature_points | update_JxW_values);
    
    
  std::vector<double> solution_real_values_cell_quads_first_refine(n_q_points);
  std::vector<Tensor<1,dim>> solution_real_gradients_cell_quads_first_refine(n_q_points);
  std::vector<Tensor<2,dim>> solution_real_hessians_cell_quads_first_refine(n_q_points);

  
  std::vector<double> solution_real_values_all_quads_first_refine;
  std::vector<Tensor<1,dim>> solution_real_gradients_all_quads_first_refine;
  std::vector<Tensor<2,dim>> solution_real_hessians_all_quads_first_refine;
  
  
  std::vector<double> solution_imag_values_cell_quads_first_refine(n_q_points);
  std::vector<Tensor<1,dim>> solution_imag_gradients_cell_quads_first_refine(n_q_points);
  std::vector<Tensor<2,dim>> solution_imag_hessians_cell_quads_first_refine(n_q_points);

  
  std::vector<double> solution_imag_values_all_quads_first_refine;
  std::vector<Tensor<1,dim>> solution_imag_gradients_all_quads_first_refine;
  std::vector<Tensor<2,dim>> solution_imag_hessians_all_quads_first_refine;
    

  if(is_solution_printed==1)
  {
    cout << "Printing solution of the first refinement\n";
    cout << "  solution is\n  " << solution << endl; 
    cout << "  solution_real is\n  " << solution_real << endl;
    cout << "  solution_imag is\n  " << solution_imag << endl;
    cout << "  solution_amp is\n  " << solution_amp << endl;
  }
  
//   obj_string="solution_real";
//   save_Vector_to_txt(obj_string,solution_real);
//   obj_string="solution_amp";
//   save_Vector_to_txt(obj_string,solution_amp);
  
    
  
  typename DoFHandler<dim>::active_cell_iterator  
  cell = dof_handler_amp.begin_active(),
  endc = dof_handler_amp.end();
  
  for (; cell!=endc; ++cell)
  {
//         cout << "cell " << cell->active_cell_index() << ", vertex(0): " << cell->vertex(0) ;
        
    fe_values.reinit (cell);
    
    fe_values.get_function_values (solution_real, solution_real_values_cell_quads_first_refine);      
    fe_values.get_function_gradients (solution_real, solution_real_gradients_cell_quads_first_refine);  
    fe_values.get_function_hessians (solution_real, solution_real_hessians_cell_quads_first_refine);  
    
    fe_values.get_function_values (solution_imag, solution_imag_values_cell_quads_first_refine);      
    fe_values.get_function_gradients (solution_imag, solution_imag_gradients_cell_quads_first_refine);  
    fe_values.get_function_hessians (solution_imag, solution_imag_hessians_cell_quads_first_refine);
    
    for (unsigned int i=0; i<n_q_points;++i)
    {
//             coords_all_quads_first_refine.push_back(fe_values.get_quadrature_points()[i](0));
        solution_real_values_all_quads_first_refine.push_back(solution_real_values_cell_quads_first_refine[i]);
        solution_real_gradients_all_quads_first_refine.push_back(solution_real_gradients_cell_quads_first_refine[i]);
        solution_real_hessians_all_quads_first_refine.push_back(solution_real_hessians_cell_quads_first_refine[i]);
        
        solution_imag_values_all_quads_first_refine.push_back(solution_imag_values_cell_quads_first_refine[i]);
        solution_imag_gradients_all_quads_first_refine.push_back(solution_imag_gradients_cell_quads_first_refine[i]);
        solution_imag_hessians_all_quads_first_refine.push_back(solution_imag_hessians_cell_quads_first_refine[i]);            
    }
  }
    
    
  triangulation.refine_global ();  
  setup_system ();                              // these three functions are used independently or inside another function, so we do not calculate time of them individually
  assemble_system ();
  solve ();  
  
  unsigned int n_q_points_one_side = (n_q_points+1)/2.0;
  
  
  std::vector<double> solution_real_values_all_quads_second_refine;
  std::vector<Tensor<1,dim>> solution_real_gradients_all_quads_second_refine;
  std::vector<Tensor<2,dim>> solution_real_hessians_all_quads_second_refine;
  
  std::vector<double> solution_imag_values_all_quads_second_refine;
  std::vector<Tensor<1,dim>> solution_imag_gradients_all_quads_second_refine;
  std::vector<Tensor<2,dim>> solution_imag_hessians_all_quads_second_refine;  

  
  std::vector<double > solution_real_values_cell_quads_second_refine_left(n_q_points_one_side);
  std::vector<Tensor<1,dim>> solution_real_gradients_cell_quads_second_refine_left(n_q_points_one_side);
  std::vector<Tensor<2,dim>> solution_real_hessians_cell_quads_second_refine_left(n_q_points_one_side);
  
  std::vector<double > solution_imag_values_cell_quads_second_refine_left(n_q_points_one_side);
  std::vector<Tensor<1,dim>> solution_imag_gradients_cell_quads_second_refine_left(n_q_points_one_side);
  std::vector<Tensor<2,dim>> solution_imag_hessians_cell_quads_second_refine_left(n_q_points_one_side);  
  
  
  std::vector<Point<dim> > left_quad_vector(n_q_points_one_side);
  
  for (unsigned int i=0; i<left_quad_vector.size();++i)
  {
    left_quad_vector[i]=quadrature_formula.get_points()[i]*2;
  }

//   cout << "  left_quad_vector: \n";
//   print_vector(left_quad_vector);
    
  Quadrature<dim>  quadrature_formula_high_2_low_left(left_quad_vector);                   // fe_values.get_quadrature_points()[2](0)  left_quad_vector       
  
  FEValues<dim> fe_values_high_2_low_left (fe_amp, quadrature_formula_high_2_low_left,
                          update_values   | update_gradients | update_hessians |
                          update_quadrature_points | update_JxW_values);
    
  std::vector<double > solution_real_values_cell_quads_second_refine_right(n_q_points_one_side);
  std::vector<Tensor<1,dim>> solution_real_gradients_cell_quads_second_refine_right(n_q_points_one_side);
  std::vector<Tensor<2,dim>> solution_real_hessians_cell_quads_second_refine_right(n_q_points_one_side);
  
  
  std::vector<double > solution_imag_values_cell_quads_second_refine_right(n_q_points_one_side);
  std::vector<Tensor<1,dim>> solution_imag_gradients_cell_quads_second_refine_right(n_q_points_one_side);
  std::vector<Tensor<2,dim>> solution_imag_hessians_cell_quads_second_refine_right(n_q_points_one_side);

  
  std::vector<Point<dim> > right_quad_vector(n_q_points_one_side);
  
  for (unsigned int i=0; i<right_quad_vector.size();++i)
  {
    right_quad_vector[i](0) = (quadrature_formula.get_points()[i+(n_q_points_one_side*2==n_q_points?n_q_points_one_side:n_q_points_one_side-1)](0)-0.5)*2;
  }
  
  Quadrature<dim>  quadrature_formula_high_2_low_right(right_quad_vector);          
  
  FEValues<dim> fe_values_high_2_low_right (fe_amp, quadrature_formula_high_2_low_right,
                          update_values   | update_gradients | update_hessians |
                          update_quadrature_points | update_JxW_values);   

  cell = dof_handler_amp.begin_active(),
  endc = dof_handler_amp.end();  
  for (; cell!=endc; ++cell)
  {
//         cout << "cell " << cell->active_cell_index() << ", vertex(0): " << cell->vertex(0) ;
        
    if (cell->active_cell_index()%2==0)
    {
      fe_values_high_2_low_left.reinit (cell);
//             
      fe_values_high_2_low_left.get_function_values (solution_real, solution_real_values_cell_quads_second_refine_left);
      fe_values_high_2_low_left.get_function_gradients (solution_real, solution_real_gradients_cell_quads_second_refine_left);
      fe_values_high_2_low_left.get_function_hessians (solution_real, solution_real_hessians_cell_quads_second_refine_left);
        
      fe_values_high_2_low_left.get_function_values (solution_imag, solution_imag_values_cell_quads_second_refine_left);
      fe_values_high_2_low_left.get_function_gradients (solution_imag, solution_imag_gradients_cell_quads_second_refine_left);
      fe_values_high_2_low_left.get_function_hessians (solution_imag, solution_imag_hessians_cell_quads_second_refine_left);
        
      for (unsigned int i=0; i<n_q_points_one_side;++i)
      {
        solution_real_values_all_quads_second_refine.push_back(solution_real_values_cell_quads_second_refine_left[i]);
        solution_real_gradients_all_quads_second_refine.push_back(solution_real_gradients_cell_quads_second_refine_left[i]);
        solution_real_hessians_all_quads_second_refine.push_back(solution_real_hessians_cell_quads_second_refine_left[i]);
        
        solution_imag_values_all_quads_second_refine.push_back(solution_imag_values_cell_quads_second_refine_left[i]);
        solution_imag_gradients_all_quads_second_refine.push_back(solution_imag_gradients_cell_quads_second_refine_left[i]);
        solution_imag_hessians_all_quads_second_refine.push_back(solution_imag_hessians_cell_quads_second_refine_left[i]);                
      }
    }else
    {
      fe_values_high_2_low_right.reinit (cell);
        
      fe_values_high_2_low_right.get_function_values (solution_real, solution_real_values_cell_quads_second_refine_right);
      fe_values_high_2_low_right.get_function_gradients (solution_real, solution_real_gradients_cell_quads_second_refine_right);
      fe_values_high_2_low_right.get_function_hessians (solution_real, solution_real_hessians_cell_quads_second_refine_right);       
        
      fe_values_high_2_low_right.get_function_values (solution_imag, solution_imag_values_cell_quads_second_refine_right);
      fe_values_high_2_low_right.get_function_gradients (solution_imag, solution_imag_gradients_cell_quads_second_refine_right);
      fe_values_high_2_low_right.get_function_hessians (solution_imag, solution_imag_hessians_cell_quads_second_refine_right);
        
      if (2*n_q_points_one_side==n_q_points)
      {
        for (unsigned int i=0; i<n_q_points_one_side;++i)
        {
            solution_real_values_all_quads_second_refine.push_back(solution_real_values_cell_quads_second_refine_right[i]);
            solution_real_gradients_all_quads_second_refine.push_back(solution_real_gradients_cell_quads_second_refine_right[i]);
            solution_real_hessians_all_quads_second_refine.push_back(solution_real_hessians_cell_quads_second_refine_right[i]);
            
            solution_imag_values_all_quads_second_refine.push_back(solution_imag_values_cell_quads_second_refine_right[i]);
            solution_imag_gradients_all_quads_second_refine.push_back(solution_imag_gradients_cell_quads_second_refine_right[i]);
            solution_imag_hessians_all_quads_second_refine.push_back(solution_imag_hessians_cell_quads_second_refine_right[i]);                    
        }  
      }else
      {
        for (unsigned int i=1; i<n_q_points_one_side;++i)
        {
            solution_real_values_all_quads_second_refine.push_back(solution_real_values_cell_quads_second_refine_right[i]);
            solution_real_gradients_all_quads_second_refine.push_back(solution_real_gradients_cell_quads_second_refine_right[i]);
            solution_real_hessians_all_quads_second_refine.push_back(solution_real_hessians_cell_quads_second_refine_right[i]);     
            
            solution_imag_values_all_quads_second_refine.push_back(solution_imag_values_cell_quads_second_refine_right[i]);
            solution_imag_gradients_all_quads_second_refine.push_back(solution_imag_gradients_cell_quads_second_refine_right[i]);
            solution_imag_hessians_all_quads_second_refine.push_back(solution_imag_hessians_cell_quads_second_refine_right[i]);                      
        }  
      }
    }
  }
        
  Vector<double> cellwise_error_real(triangulation_first_refine.n_active_cells());
  Vector<double> cellwise_error_imag(triangulation_first_refine.n_active_cells());
  
  typename DoFHandler<dim>::active_cell_iterator
  cell_first_refine = dof_handler_amp_first_refine.begin_active(),                          // for the solution
  endc_first_refine = dof_handler_amp_first_refine.end();
  
  for (; cell_first_refine!=endc_first_refine; ++cell_first_refine)
  {
    int cell_index = cell_first_refine->active_cell_index();
    fe_values.reinit (cell_first_refine);
    error_quad_real=0;
    error_quad_imag=0;
      
    for (unsigned int q_index=0; q_index<n_q_points; ++q_index)
    {
      error_quad_real += std::pow(solution_real_values_all_quads_first_refine[n_q_points*cell_index + q_index] - solution_real_values_all_quads_second_refine[n_q_points*cell_index + q_index],2 ) * fe_values.JxW (q_index) ;   
      error_quad_imag += std::pow(solution_imag_values_all_quads_first_refine[n_q_points*cell_index + q_index] - solution_imag_values_all_quads_second_refine[n_q_points*cell_index + q_index],2 ) * fe_values.JxW (q_index) ;   
    }
        
    cellwise_error_real[cell_index] = std::sqrt(error_quad_real);                 // cellwise error in L2 norm
    cellwise_error_imag[cell_index] = std::sqrt(error_quad_imag);
  }
    
  solution_real_L2_error = cellwise_error_real.l2_norm();
  solution_imag_L2_error = cellwise_error_imag.l2_norm();
    
  cell_first_refine = dof_handler_amp_first_refine.begin_active();                    // for the gradient
    
  for (; cell_first_refine!=endc_first_refine; ++cell_first_refine)
  {
    int cell_index = cell_first_refine->active_cell_index();
    fe_values.reinit (cell_first_refine);
    error_quad_real=0;
    error_quad_imag=0;
    
    for (unsigned int q_index=0; q_index<n_q_points; ++q_index)
    {
        error_quad_real += std::pow(solution_real_gradients_all_quads_first_refine[n_q_points*cell_index + q_index][0] - solution_real_gradients_all_quads_second_refine[n_q_points*cell_index + q_index][0],2 ) * fe_values.JxW (q_index) ;   // *
        error_quad_imag += std::pow(solution_imag_gradients_all_quads_first_refine[n_q_points*cell_index + q_index][0] - solution_imag_gradients_all_quads_second_refine[n_q_points*cell_index + q_index][0],2 ) * fe_values.JxW (q_index) ;   // * 
    }
    
    cellwise_error_real[cell_index] = std::sqrt(error_quad_real);
    cellwise_error_imag[cell_index] = std::sqrt(error_quad_imag);
  }
    
  solution_real_H1_semi_error = cellwise_error_real.l2_norm();
  solution_imag_H1_semi_error = cellwise_error_imag.l2_norm();
    
//   cout << "    solution_real_H1_semi_error is :  " << solution_real_H1_semi_error << endl;
    
//     cout << "    For the second-order derivative:  " << endl;
  cell_first_refine = dof_handler_amp_first_refine.begin_active();
    
  for (; cell_first_refine!=endc_first_refine; ++cell_first_refine)
  {
    int cell_index = cell_first_refine->active_cell_index();
    fe_values.reinit (cell_first_refine);
    error_quad_real=0;
    error_quad_imag=0;
    
    for (unsigned int q_index=0; q_index<n_q_points; ++q_index)
    {
            error_quad_real += std::pow(solution_real_hessians_all_quads_first_refine[n_q_points*cell_index + q_index][0][0] - solution_real_hessians_all_quads_second_refine[n_q_points*cell_index + q_index][0][0],2 ) * fe_values.JxW (q_index) ;  
            error_quad_imag += std::pow(solution_imag_hessians_all_quads_first_refine[n_q_points*cell_index + q_index][0][0] - solution_imag_hessians_all_quads_second_refine[n_q_points*cell_index + q_index][0][0],2 ) * fe_values.JxW (q_index) ;  
    }
    
    cellwise_error_real[cell_index] = std::sqrt(error_quad_real);
    cellwise_error_imag[cell_index] = std::sqrt(error_quad_imag);
  }
    
  solution_real_H2_semi_error = cellwise_error_real.l2_norm();
  solution_imag_H2_semi_error = cellwise_error_imag.l2_norm();
    
//     cout << "    solution_real_H2_semi_error is :  " << solution_real_H2_semi_error << endl;    
    
}


template <int dim>
void Step4_Complex<dim>::process_errors ()
{
  TimerOutput::Scope t(computing_timer, "process errors");
  solution_L2_error = pow(pow(solution_real_L2_error,2)+pow(solution_imag_L2_error,2), 0.5);
  solution_H1_semi_error = pow(pow(solution_real_H1_semi_error,2)+pow(solution_imag_H1_semi_error,2), 0.5);
  solution_H2_semi_error = pow(pow(solution_real_H2_semi_error,2)+pow(solution_imag_H2_semi_error,2), 0.5);
}
    
    
    
template <int dim>
void Step4_Complex<dim>::print_errors_and_CPU ()
{
  cout << "Printing errors and CPU\n";
  
  cout << "  solu_real_L2 = " << solu_real_L2 << endl;
  cout << "  solu_imag_L2 = " << solu_imag_L2 << endl;
  cout << "  solu_L2 = " << solu_L2 << endl;

  cout << "\n";
  cout << "  ||Eh||_L2_real = " << solution_real_L2_error << ", ";
  cout << "r_N_real = " << 0 << "\n";
  cout << "  ||Eh||_H1_seminorm_real = " << solution_real_H1_semi_error << ", ";
  cout << "r_Np_real = " << 0 << "\n";  
  cout << "  ||Eh||_H2_seminorm_real = " << solution_real_H2_semi_error << ", ";
  cout << "r_Npp_real = " << 0 << "\n";
  
  cout << "\n";
  
  cout << "  ||Eh||_L2_imag = " << solution_imag_L2_error << ", ";
  cout << "r_N_imag = " << 0 << "\n";
  cout << "  ||Eh||_H1_seminorm_imag = " << solution_imag_H1_semi_error << ", ";
  cout << "r_Np_imag = " << 0 << "\n";  
  cout << "  ||Eh||_H2_seminorm_imag = " << solution_imag_H2_semi_error << ", ";
  cout << "r_Npp_imag = " << 0 << "\n";
  
  cout << "\n";
  
  cout << "  ||Eh||_L2 = " << solution_L2_error << "\n";
  cout << "  ||Eh||_H1_seminorm = " << solution_H1_semi_error << "\n";  
  cout << "  ||Eh||_H2_seminorm = " << solution_H2_semi_error << "\n";
  
  cout << "\n";
  
  cout << "  total_CPU_time: " << total_CPU_time << "\n";
    
}


template <int dim>
void Step4_Complex<dim>::run ()
{
  make_grid();
  
  setup_system ();
  assemble_system ();
  
#if 1
  solve ();
  
  if(is_results_stored==1)
  {
    output_results ();  
  }
  
  compute_l2_norm ();
  compute_errors_quad ();
  process_errors();
  
  
  total_CPU_time += computing_timer.return_total_cpu_time ();
  if(total_CPU_time<0.001)
  {
      total_CPU_time = 0.001;
  }

  print_errors_and_CPU ();  
  
  printToFile();
  
  computing_timer.print_summary();
//   return solu_real_L2;
  
#endif
}



#endif

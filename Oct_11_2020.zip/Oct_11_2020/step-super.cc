

#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/logstream.h>
#include <deal.II/base/function.h>
#include <deal.II/base/function.templates.h>

#include <deal.II/lac/block_vector.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/block_sparse_matrix.h>
#include <deal.II/lac/solver_cg1.h>
#include <deal.II/lac/sparse_direct.h>
#include <deal.II/lac/solver_gmres.h>

#include <deal.II/lac/precondition.h>

#include <deal.II/grid/tria.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>
#include <deal.II/dofs/dof_handler.h>
#include <deal.II/dofs/dof_renumbering.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/dofs/dof_tools.h>

#include <deal.II/fe/fe_bernstein.h>                        
#include <deal.II/fe/fe_dgq.h>                        
#include <deal.II/fe/fe_system.h>
#include <deal.II/fe/fe_values.h>
#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/vector_tools.templates.h>

#include <deal.II/numerics/matrix_tools.h>
#include <deal.II/numerics/data_out.h>
#include <deal.II/base/timer.h>
#include <deal.II/base/timer_return_total_cpu_time.h>

#include <fstream>
#include <iostream>
#include <type_traits>
#include <stdlib.h>

#include <deal.II/base/tensor_function.h>
#include <deal.II/base/tensor_function.templates.h>

#include <complex>
#include <cmath>

#define pi 3.141592653589793238462643

typedef double real_t;

using namespace dealii;
using namespace std;

#include"../6_headers/1_cpp/1_dealii/common_function.h"

#include"../6_headers/1_cpp/1_dealii/function_for_custom_error_std.h"
#include"../6_headers/1_cpp/1_dealii/function_for_custom_error_mix.h"

#include<1_real_valued/mainclass_step_4_real.h>
#include<2_complex_valued/mainclass_step_4_complex.h>
#include<1_real_valued/mainclass_step_20_real.h>
#include<2_complex_valued/mainclass_step_20_complex.h>
// #include<2_complex_valued/mainclass_step_20_complex_validation.h>                // include me for checking the 1d validation results of Dec. 17, 2019

int main ( int argc, char *argv[] )
{
  unsigned int id_case;
  int id_quad_assem_incre;
  unsigned int id_loc_coeff_diff;
  double coeff_inner_x;
  double tol_prm = 1e-16;
  unsigned int degree = 1;
  unsigned int refine = 1;

  if ( argc != 8 )
  {
    std::cout<<"usage: "<< argv[0] <<" <id_case> <id_quad_assem_incre> <id_loc_coeff_diff> <coeff_inner_x> <tol_prm> <degree> <refinement>\n";
    exit(EXIT_FAILURE);
  } else 
  {
    id_case = atoi(argv[1]);
    id_quad_assem_incre = atoi(argv[2]);
    id_loc_coeff_diff = atoi(argv[3]);
    coeff_inner_x = atof(argv[4]);
    tol_prm = atof(argv[5]);
    degree = atoi(argv[6]);
    refine = atoi(argv[7]);
  }
  try
  {
    for (int i = 0; i < 1; i++)
    {
      const int dim = 2;
      unsigned int id_problem = 3;                  // '0': standard FEM for the real-valued problem
                                                    // '1': mixed FEM for the real-valued problem
                                                    // '2': standard FEM for the complex-valued problem
                                                    // '3': mixed FEM for the complex-valued problem
                                                                             
      std::cout << "Input arguments: \n"
                << "  id_case: " << id_case << "\n"
                << "  param for the number of quadrature points: " << id_quad_assem_incre << "\n"
                << "  id_loc_coeff_diff: " << id_loc_coeff_diff << "\n"
                << "  coeff_inner_x: " << coeff_inner_x << "\n"
                << "  tol_prm: " << tol_prm << "\n"
                << "  degree: " << degree << "\n"
                << "  refine: " << refine << "\n";  

      
      switch (id_problem)
      {
        case 0:
        {
          Step4_Real<dim> second_order_differential_problem(id_case, id_quad_assem_incre, coeff_inner_x, tol_prm, degree, refine);
          second_order_differential_problem.run ();
          break;
        }
        case 1:
        {
          MixedLaplaceProblem_Real<dim> second_order_differential_problem(id_case, id_quad_assem_incre, id_loc_coeff_diff, coeff_inner_x, tol_prm, degree, refine);
          second_order_differential_problem.run ();              
          break;
        }
        case 2:
        {
          Step4_Complex<dim> second_order_differential_problem(id_case, 1.0, degree, refine);
          second_order_differential_problem.run ();
          break;
        }          
        case 3:
        {         
          MixedLaplaceProblem_Complex<dim> second_order_differential_problem(id_case, 1.0, degree, refine);                // _Validation
          second_order_differential_problem.run ();             
          break;
        }
        default:
        {
          break;
        }
      }
    }
      
  }
  catch (std::exception &exc)
  {
    std::cerr << std::endl << std::endl
              << "----------------------------------------------------"
              << std::endl;
    std::cerr << "Exception on processing: " << std::endl
              << exc.what() << std::endl
              << "Aborting!" << std::endl
              << "----------------------------------------------------"
              << std::endl;

    return 1;
  }
  catch (...)
  {
    std::cerr << std::endl << std::endl
              << "----------------------------------------------------"
              << std::endl;
    std::cerr << "Unknown exception!" << std::endl
              << "Aborting!" << std::endl
              << "----------------------------------------------------"
              << std::endl;
    return 1;
  }

  return 0;
}
